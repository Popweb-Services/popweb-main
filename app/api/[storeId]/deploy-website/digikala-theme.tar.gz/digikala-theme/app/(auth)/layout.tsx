import Image from "next/image"
import { redirect } from "next/navigation"
import { getLogo } from "@/actions/get-logo"

import { getAuthSession } from "@/lib/session"
import { getStore } from "@/actions/get-store"


interface AuthLayoutProps {
  children: React.ReactNode
}

const AuthLayout = async ({ children }:AuthLayoutProps) => {
  const session = await getAuthSession()
  const store = await getStore()
  console.log(session)
  if (session) {
    return redirect("/profile")
  }
  return (
    <>
      <div className="flex h-full w-full items-center justify-center px-4 ">
        <div className="relative w-[400px] rounded-lg border-2 p-8">
          <div className="flex items-center justify-center">
          
          </div>
          {children}
        </div>
      </div>
    </>
  )
}

export default AuthLayout
