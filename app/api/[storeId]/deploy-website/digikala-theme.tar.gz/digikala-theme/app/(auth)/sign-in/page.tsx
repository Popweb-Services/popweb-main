import SignInForm from "@/components/sign-in-form"

interface SignInPageProps {}

const SignInPage: React.FC<SignInPageProps> = ({}) => {
  return (
    <>
      <SignInForm />
    </>
  )
}

export default SignInPage
