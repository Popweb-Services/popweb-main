import "@/styles/globals.css"
import { Metadata } from "next"
import { cookies, headers } from "next/headers"
import setDeviceIdCookie from "@/actions/set-deviceId-cookie"
import Providers from "@/providers/providers"
import NextTopLoader from "nextjs-toploader"
import { uuid } from "uuidv4"

import { siteConfig } from "@/config/site"
import { fontSans, fontYekan } from "@/lib/fonts"
import { getAuthSession } from "@/lib/session"
import { cn } from "@/lib/utils"

export const metadata: Metadata = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "white" },
    { media: "(prefers-color-scheme: dark)", color: "black" },
  ],
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-16x16.png",
    apple: "/apple-touch-icon.png",
  },
}

interface RootLayoutProps {
  children: React.ReactNode
}

export default async function RootLayout({ children }: RootLayoutProps) {
  const session = await getAuthSession()
  return (
    <>
      <html lang="fa" suppressHydrationWarning>
        <body
          className={cn(fontSans.variable, fontYekan.className, "relative")}
        >
          <NextTopLoader />
          <Providers session={session}>{children}</Providers>
        </body>
      </html>
    </>
  )
}
