import { NextResponse } from "next/server"
import axios, { AxiosError } from "axios"
import { z } from "zod"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const requestSchema = z.object({
      phoneNumber: z.string(),
      code: z.string(),
    })
    const { code, phoneNumber } = requestSchema.parse(body)
    await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/customers/${phoneNumber}`,
      { code: code }
    )
    return new NextResponse("code is correct", { status: 200 })
  } catch (error) {
    if (error instanceof AxiosError && error.response?.status === 401) {
      return new NextResponse("invalid otp", { status: 401 })
    } else if (error instanceof z.ZodError) {
      return new NextResponse(error.message, { status: 422 })
    }
    return new NextResponse("internal server error ", { status: 500 })
  }
}
