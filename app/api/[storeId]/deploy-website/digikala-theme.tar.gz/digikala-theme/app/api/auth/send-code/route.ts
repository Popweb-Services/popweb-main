import { NextResponse } from "next/server"
import axios from "axios"

import { phoneNumberValidator } from "@/lib/validators/auth"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const { phone } = phoneNumberValidator.parse(body)
    const { data } = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/customers`,
      { phone }
    )
    return NextResponse.json(data, { status: 200 })
  } catch (error) {
    console.log("[SEND_CODE]", error)
    return new NextResponse("internal server error", { status: 500 })
  }
}
