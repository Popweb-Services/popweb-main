import { NextResponse } from "next/server"
import axios from "axios"
import { z } from "zod"

export async function PATCH(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const requestSchema = z.object({
      cartItemId: z.string(),
    })
    const { cartItemId } = requestSchema.parse(body)
    await axios.patch(
      `${process.env.NEXT_PUBLIC_API_URL}/cart/increment/${cartItemId}`
    )
    return new NextResponse("item decremented", { status: 200 })
  } catch (error) {
    console.log("[DECREMENT]", error)
    if (error instanceof z.ZodError) {
      return new NextResponse("cart item id is missing")
    }
    return new NextResponse("internal server error", { status: 500 })
  }
}
