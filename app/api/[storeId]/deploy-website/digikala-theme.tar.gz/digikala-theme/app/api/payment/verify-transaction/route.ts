import { NextResponse } from "next/server"
import axios, { AxiosError } from "axios"
import { z } from "zod"

import { Order } from "@/types/order"
import {
  TransactionInfoResponse,
  VerifyTransactionResponse,
} from "@/types/vandar"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const requestSchema = z.object({
      orderId: z.string(),
      token: z.string(),
    })
    const { orderId, token } = requestSchema.parse(body)
    const { data: order } = await axios.get<Order>(
      `${process.env.NEXT_PUBLIC_API_URL}/order/${orderId}`
    )
    const { data: transactionInfo } = await axios.post<TransactionInfoResponse>(
      "https://ipg.vandar.io/api/v3/transaction",
      {
        api_key: process.env.VANDAR_API_KEY,
        token,
      }
    )
    const { data: verifyTransactionResponse } =
      await axios.post<VerifyTransactionResponse>(
        "https://ipg.vandar.io/api/v3/verify",
        {
          api_key: process.env.VANDAR_API_KEY,
          token,
        }
      )
    if (verifyTransactionResponse.status === 1) {
      // update order to paid
      await axios.patch(
        `${process.env.NEXT_PUBLIC_API_URL}/orders/${orderId}`,
        { api_key: process.env.VANDAR_API_KEY, token }
      )
      return new NextResponse("transaction verified", { status: 200 })
    } else {
      return new NextResponse("there was a problem verifying transaction", {
        status: 400,
      })
    }
  } catch (error) {
    console.log("[VERIFY_TRANSACTION]", error)
    if (error instanceof z.ZodError) {
      return NextResponse.json(error.message, { status: 422 })
    }
    if (error instanceof AxiosError) {
      return new NextResponse("axios error", { status: 400 })
    }
    return new NextResponse("internal server error", { status: 500 })
  }
}
