import { NextResponse } from "next/server"
import axios from "axios"
import { object, z } from "zod"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json()
    const requestSchema = z.object({
      cartItems: z.any().array(),
      shippingRateId: z.string(),
      customerAddressId: z.string(),
      customerId: z.string(),
    })
    const { cartItems, customerAddressId, customerId, shippingRateId } =
      requestSchema.parse(body)
    const { data } = await axios.post(
      `${process.env.NEXT_PUBLIC_API_URL}/place-order`,
      { cartItems, shippingRateId, customerAddressId, customerId }
    )
    return NextResponse.json(data, { status: 200 })
  } catch (error) {
    console.log(error)
    if (error instanceof z.ZodError) {
      return NextResponse.json(error.message, { status: 422 })
    }
    return new NextResponse("internal server error", { status: 500 })
  }
}
