import { waitForDebugger } from "inspector"
import { NextResponse } from "next/server"
import axios from "axios"
import { z } from "zod"

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const requestSchema = z.object({
      customerId: z.string().optional(),
      variantId: z.string().optional(),
      deviceId: z.string().optional(),
      productId: z.string(),
    })
    const body = await request.json()
    const { customerId, deviceId, productId, variantId } =
      requestSchema.parse(body)
    await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/cart`, {
      customerId,
      variantId,
      deviceId,
      productId,
    })
    return new NextResponse("producted added to cart", { status: 200 })
  } catch (error) {
    console.log(error)
    if (error instanceof z.ZodError) {
      return NextResponse.json(error.message, { status: 422 })
    }
    return new NextResponse("internal server error", { status: 500 })
  }
}
