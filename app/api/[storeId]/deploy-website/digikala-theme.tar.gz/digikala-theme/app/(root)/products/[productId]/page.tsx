import { Metadata, ResolvingMetadata } from "next"
import { cookies } from "next/headers"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import getCartItemsByDeviceId from "@/actions/get-cart-items-by-device-id"
import { getProductById } from "@/actions/get-product"
import { X } from "lucide-react"

import { CartItem, Product, Variant } from "@/types/products"
import { priceFormatter } from "@/lib/formatter"
import { getAuthSession } from "@/lib/session"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import EditorOutput from "@/components/ui/editor-output"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import SaleBadge from "@/components/ui/sale-badge"
import { Separator } from "@/components/ui/separator"
import MobileAddToCart from "@/components/mobile-add-to-cart"
import ProductAddToCart from "@/components/product-add-to-cart"

import Gallery from "./components/gallery"

interface ProductPageProps {
  params: {
    productId: string
  }
}

export async function generateMetadata(
  { params }: ProductPageProps,
): Promise<Metadata> {
  const product = await getProductById(params.productId)
  return {
    title: `مشخصات، قیمت و خرید ${product.name}`,
    alternates: {
      canonical: `/products/${params.productId}`,
    },
  }
}

const ProductPage = async ({ params }:ProductPageProps) => {
  const session = await getAuthSession()
  let product: Product
  try {
    product = await getProductById(params.productId)
    if (product === null) {
      return notFound()
    }
  } catch (error) {
    return notFound()
  }
  const deviceId = cookies().get("device_id")?.value
  let cartItems: CartItem[] = []
  if (deviceId) {
    cartItems = await getCartItemsByDeviceId(deviceId)
  } else {
    // get customer cart items
  }
  return (
    <>
      <div
        dir="rtl"
        className="mx-auto grid max-w-5xl grid-cols-2 gap-x-8 px-4 pt-[100px] max-md:grid-cols-1"
      >
        <div className="w-full">
          <div className="relative w-full">
            <Gallery
              productName={product.name}
              imageUrls={product.images!.map((image) => image.imageUrl)}
              mainImageUrl={product.mainImageUrl}
            />
          </div>
        </div>
        <div className="w-full max-md:mt-6 ">
          {product.categoryId && product.category && (
            <Link
              href={`/categories/${product.categoryId}`}
              className="text-primaryColor"
            >
              {product.category.name}
            </Link>
          )}

          <h2 className="text-xl font-bold">{product.name}</h2>
          <Separator className="mt-4" />
          <ProductAddToCart cartItems={cartItems} product={product} session={session} />
        </div>
      </div>
      {product.description && (
        <div dir="rtl" className="container mt-4 flex flex-col space-y-3">
          <div className="w-3/4">
            <h2 className="text-xl font-bold">توضیحات</h2>
            <Separator />
            <EditorOutput content={product.description} />
          </div>
        </div>
      )}
    </>
  )
}

export default ProductPage
