import { ReactNode } from "react"
import Image from "next/image"
import Link from "next/link"
import { redirect } from "next/navigation"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import { getStore } from "@/actions/get-store"
import { RiShoppingCartLine } from "react-icons/ri"
import { TbTruck } from "react-icons/tb"

import { getAuthSession } from "@/lib/session"
import OrderSteps from "@/components/order-steps"
import OrderSummary from "@/components/order-summary"

interface PlaceOrderProps {
  children: ReactNode
}

const PlaceOrder = async ({ children }: PlaceOrderProps) => {
  const store = await getStore()
  const session = await getAuthSession()
  if (!session?.user) {
    return redirect("/sign-in?backUrl=/checkout/shipping")
  }
  const cartItems = await getCartItemsByCustomerId(session.user.id)
  return (
    <>
      <div dir="rtl" className="container p-6 max-md:p-0 max-md:bg-neutral-100">
        <div className="w-full bg-white border rounded-lg py-6 flex flex-col gap-y-6 justify-center items-center">
        
          <OrderSteps />
        </div>
        
        {children}
      </div>
    </>
  )
}

export default PlaceOrder
