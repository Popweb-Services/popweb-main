import { Metadata } from "next"
import { redirect } from "next/navigation"
import { getAddresses } from "@/actions/get-addresses"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import { getCustomer } from "@/actions/get-customer"
import { getShippingRateById } from "@/actions/get-shipping-rate-by-id"
import { getShippingRates } from "@/actions/get-shipping-rates"
import { getStore } from "@/actions/get-store"

import { getAuthSession } from "@/lib/session"
import CreateAddressModal from "@/components/ui/modals/create-address-modal"

import PaymentClient from "./payment-client"

interface PaymentPageProps {
  searchParams: {
    [key: string]: string
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const store = await getStore()
  return {
    title: `${store.name} - نحوه ارسال سفارش`,
    description: store.description,
    alternates: {
      canonical: "/checkout/cart",
    },
  }
}

const PaymentPage = async ({ searchParams }: PaymentPageProps) => {
  const selectedShippingRate = await getShippingRateById(
    searchParams.shippingRate
  )
  const addressId = searchParams.addressId
  if (!addressId) {
    return redirect("/checkout/shipping")
  }
  if (!selectedShippingRate) {
    return redirect("/checkout/shipping")
  }
  const session = await getAuthSession()
  const cartItems = await getCartItemsByCustomerId(session?.user.id!)
  if (cartItems.length === 0) {
    return redirect("/checkout/cart")
  }
  const customer = await getCustomer(session?.user.id!)

  // await new Promise((resolve) => setTimeout(resolve, 100000))
  return (
    <>
      <PaymentClient
        addressId={addressId}
        shippingRate={selectedShippingRate}
        cartItems={cartItems}
        customer={customer}
      />
    </>
  )
}

export default PaymentPage
