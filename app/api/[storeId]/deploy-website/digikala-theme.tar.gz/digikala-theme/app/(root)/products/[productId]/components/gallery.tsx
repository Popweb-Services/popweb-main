"use client"

import Image from "next/image"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface GalleryProps {
  productName: string
  mainImageUrl: string
  imageUrls: string[]
  isDiscounted?: boolean
}

const Gallery: React.FC<GalleryProps> = ({
  imageUrls,
  mainImageUrl,
  productName,
  isDiscounted,
}) => {
  return (
    <>
      <Tabs defaultValue={mainImageUrl}>
        {imageUrls.map((url) => (
          <TabsContent value={url}>
            <Image
            title={productName}
              src={url}
              alt="product image"
              key={url}
              width={1000}
              height={1000}
              className="relative h-full w-full rounded-lg object-cover"
            />
            {isDiscounted && (
              <div className="absolute right-5 top-5 select-none rounded-full border bg-white px-2 text-lg font-bold text-primaryColor">
                تخفیف
              </div>
            )}
          </TabsContent>
        ))}
        <TabsList className="mt-4 grid h-full grid-cols-4">
          {imageUrls.map((url) => (
            <TabsTrigger value={url}>
              <Image
              title={productName}
                src={url}
                alt="product image"
                key={url}
                width={1000}
                height={1000}
                className="h-full w-full"
              />
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
    </>
  )
}

export default Gallery
