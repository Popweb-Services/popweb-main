"use client"

import { Suspense, useTransition } from "react"
import {
  ReadonlyURLSearchParams,
  RedirectType,
  usePathname,
  useRouter,
  useSearchParams,
} from "next/navigation"
import { getProducts } from "@/actions/get-products"
import { getProductsByCategoryId } from "@/actions/get-products-by-category-id"
import { useInfiniteQuery } from "@tanstack/react-query"
import { BiBox } from "react-icons/bi"
import { ImSpinner8 } from "react-icons/im"
import InfiniteScroll from "react-infinite-scroll-component"

import { Category, Product } from "@/types/products"
import { cn } from "@/lib/utils"
import ProductCard from "@/components/ui/product-card"
import ProductCardSkeleton from "@/components/ui/product-card-skeleton"
import { Separator } from "@/components/ui/separator"

interface ProductsClientProps {
  products: Product[]
  category: Category
}

const ProductsClient: React.FC<ProductsClientProps> = ({
  category,
  products,
}) => {
  const LIMIT = 20
  const searchParams = useSearchParams()
  const categoryId = searchParams.get("category")
  const [isPending, startTransition] = useTransition()

  const pathname = usePathname()
  const router = useRouter()
  return (
    <>
      {isPending && (
        <div className="fixed inset-0 z-50 bg-white opacity-50 flex items-center justify-center">
          <ImSpinner8 className="w-10 h-10 text-primaryColor animate-spin" />
        </div>
      )}
      <div className="col-span-4 py grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4">
        <div
          className="col-span-2 sm
          :col-span-3 md:col-span-4 lg:col-span-5 max-lg:px-4"
        >
          <div className="flex items-center py-2 gap-x-3">
            {category.subcategories.map((subCategory) => (
              <div className="p-2 border rounded-lg">{subCategory.name}</div>
            ))}
          </div>
          <div className="flex items-center gap-x-3 text-sm">
            <p>مرتب سازی بر اساس :</p>
            <div
              onClick={() => {
                startTransition(() => {
                  router.push(
                    `${pathname}?category=${categoryId}&cheapest=${true}`
                  )
                })
              }}
              className={cn(
                searchParams.get("cheapest") === "true" && "text-primaryColor",
                "cursor-pointer relative "
              )}
            >
              <p className="py-2"> کمترین قیمت</p>
              {searchParams.get("cheapest") === "true" && (
                <div className="w-full bg-primaryColor bottom-0 right-0 h-[4px] absolute" />
              )}
            </div>
            <div
              onClick={() => {
                startTransition(() => {
                  router.push(
                    `${pathname}?category=${categoryId}&cheapest=${false}`
                  )
                })
              }}
              className={cn(
                searchParams.get("cheapest") === "false" && "text-primaryColor",
                "cursor-pointer relative "
              )}
            >
              <p className="py-2"> بیشترین قیمت</p>
              {searchParams.get("cheapest") === "false" && (
                <div className="w-full bg-primaryColor bottom-0 right-0 h-[4px] absolute" />
              )}
            </div>
          </div>
          <Separator />
        </div>
        <div className="col-span-5 pt-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4">
            {products.length === 0 && (
              <div className="col-span-2 gap-y-4 sm:col-span-3 md:col-span-4 h-[500px] w-full flex flex-col items-center justify-center">
                <BiBox className="w-20 h-20 text-neutral-300" />
                <div className="text-center gap-y-2">
                  <p className="text-xl font-bold">کالایی برای نمایش وجود ندارد</p>
                  <p>
                    در حال حاضر کالایی برای نمایش در این دسته بندی وجود ندارد
                  </p>
                </div>
              </div>
            )}
            {products.map((product) => (
              <Suspense key={product.id} fallback={<ProductCardSkeleton />}>
                <ProductCard product={product} />
              </Suspense>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}

export default ProductsClient
