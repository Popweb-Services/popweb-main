import { Metadata } from "next"
import { notFound } from "next/navigation"
import { getCategoryById } from "@/actions/get-category-by-id"
import { getProductsByCategoryId } from "@/actions/get-products-by-category-id"
import { BiCategory } from "react-icons/bi"

import { Product } from "@/types/products"
import generateQueryString from "@/lib/generate-query-string"
import { Separator } from "@/components/ui/separator"
import Filters from "@/components/filters"

import ProductsClient from "./products-client"

interface ProductsPageProps {
  searchParams: {
    [key: string]: string
  }
}

const ProductsPage = async ({ searchParams }: ProductsPageProps) => {
  const category = await getCategoryById(searchParams.category)

  const products = await getProductsByCategoryId(
    category.id,
    generateQueryString(searchParams)
  )
  const productOptions = products.map((product) => product.options)
  console.log(productOptions)
  return (
    <>
      <div
        dir="rtl"
        className="grid grid-cols-4 container gap-x-4 pt-[140px] max-lg:pt-[65px] max-lg:my-0 max-lg:px-0 max-lg:grid-cols-1"
      >
        <div className="w-full p-6 flex items-center rounded-xl max-lg:rounded-none bg-primaryColor col-span-5">
          <div className="rounded-lg border flex items-center justify-center w-14 h-14">
            <BiCategory className="w-9 h-9 text-white" />
          </div>
          <p className="text-white mr-4">{category.name}</p>
        </div>

        <Filters categoryId={category.id} />

        <ProductsClient products={products} category={category} />
      </div>
    </>
  )
}

export default ProductsPage
