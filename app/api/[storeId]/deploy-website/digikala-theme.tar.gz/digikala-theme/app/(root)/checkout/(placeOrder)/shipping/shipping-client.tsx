"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import { Session } from "next-auth"
import { AiOutlineLeft } from "react-icons/ai"
import { GrLocation } from "react-icons/gr"
import { MdOutlineAddLocation } from "react-icons/md"
import { TbTruck } from "react-icons/tb"

import { Address } from "@/types/address"
import { Customer } from "@/types/customer"
import { CartItem } from "@/types/products"
import { ShippingRate } from "@/types/shipping-rate"
import { priceFormatter } from "@/lib/formatter"
import { getAuthSession } from "@/lib/session"
import { cn } from "@/lib/utils"
import useChangeAddressModal from "@/hooks/use-change-address-modal"
import useCreateAddressModal from "@/hooks/use-create-address-modal"
import useSelectedAddress from "@/hooks/use-selected-address"
import { buttonVariants } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ChangeAddressModal from "@/components/ui/modals/change-address-modal"
import CreateAddressModal from "@/components/ui/modals/create-address-modal"
import QuantityButton from "@/components/ui/quantity-button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import OrderSummary from "@/components/order-summary"
import ShippingPageCartItemsSlider from "@/components/shipping-page-cart-items-slider"

interface ShippingClientProps {
  shippingRates: ShippingRate[]
  customer: Customer
  addresses: Address[]
  cartItems: CartItem[]
}

const ShippingClient: React.FC<ShippingClientProps> = ({
  shippingRates,
  customer,
  cartItems,
  addresses,
}) => {
  const [totalPrice, setTotalPrice] = useState(0)
  const { onOpen: onChangeAddressModalOpen, setAddresses } =
    useChangeAddressModal()
  const { onOpen } = useCreateAddressModal()
  useState(false)
  const [selectedShippingRate, setSelectedShippingRate] = useState<
    ShippingRate | undefined
  >(shippingRates[0])
  const { selectedAddress, setAddress } = useSelectedAddress()
  useEffect(() => {
    if (addresses.length > 0 && !selectedAddress) {
      setAddress(addresses[0])
    }
  }, [addresses])
  useEffect(() => {
    const totalBasketPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        if (
          item.variant.priceAfterDiscount &&
          item.variant.priceAfterDiscount > 0 &&
          item.variant.priceAfterDiscount < item.variant.price
        ) {
          return acc + item.variant.priceAfterDiscount * item.quantity
        } else {
          return acc + item.variant.price * item.quantity
        }
      } else {
        if (
          item.product.priceAfterDiscount &&
          item.product.priceAfterDiscount > 0 &&
          item.product.priceAfterDiscount < item.product.price
        ) {
          return acc + item.product.priceAfterDiscount * item.quantity
        } else {
          return acc + item.product.price * item.quantity
        }
      }
    }, 0)
    if (selectedShippingRate) {
      setTotalPrice(totalBasketPrice + selectedShippingRate.price)
    } else {
      setTotalPrice(totalPrice)
    }
  }, [cartItems])
  return (
    <>
      <CreateAddressModal customer={customer} />
      <ChangeAddressModal customer={customer} />

      <div className="grid grid-cols-4 max-lg:grid-cols-1 gap-2 mt-4 pb-[80px]">
        <div className="col-span-3 space-y-4 bg-white max-md:col-span-1 ">
          {addresses.length === 0 ? (
            <div
              onClick={onOpen}
              className="flex cursor-pointer items-center p-4 gap-x-2 border rounded-lg"
            >
              <MdOutlineAddLocation className="w-6 h-6" />
              <p className="text-lg">افزودن آدرس</p>

              <AiOutlineLeft />
            </div>
          ) : (
            <div className="flex flex-col max-md:rounded-none max-md:border-none bg-white p-4 gap-x-2 border rounded-lg">
              <div className="flex items-center bg-white">
                <GrLocation className="mx-4 w-6 h-6" />
                <div className="space-y-2">
                  <p className="text-sm text-neutral-500">آدرس تحویل سفارش</p>
                  <p className="text-lg font-bold">
                    {selectedAddress?.address}
                  </p>
                  <p>{selectedAddress?.recieverName}</p>
                </div>
              </div>

              <div className="flex justify-end text-primaryColor bottom-5 left-5 items-center gap-x-2">
                <div className="flex items-center gap-x-2 cursor-pointer">
                  <button
                    onClick={() => {
                      setAddresses([...addresses])
                      onChangeAddressModalOpen()
                    }}
                  >
                    تغییر یا ویرایش آدرس
                  </button>

                  <AiOutlineLeft />
                </div>
              </div>
            </div>
          )}
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <p>کالاها</p>
            <ShippingPageCartItemsSlider cartItems={cartItems} />
            <div className="flex items-center gap-x-2">
              <TbTruck className="w-5 h-5 -scale-x-100" />
              <p>انتخاب نحوه ارسال</p>
            </div>
            <div className="w-full border rounded-lg p-4">
              {shippingRates.length > 0 ? (
                <>
                  <RadioGroup
                    onValueChange={(value) => {
                      setSelectedShippingRate(
                        shippingRates.find((rate) => rate.id === value)
                      )
                    }}
                    className="divide-y-2"
                    dir="rtl"
                    defaultValue={shippingRates[0].id}
                  >
                    {shippingRates.map((rate) => (
                      <div className="flex py-2 flex-col gap-y-2">
                        <div className="flex items-center gap-x-3">
                          <RadioGroupItem value={rate.id} />
                          <p>{rate.name}</p>
                        </div>
                        <div className="flex items-center text-sm text-neutral-500 mr-5 gap-x-2">
                          <p>هزینه ارسال :</p>
                          <p>{priceFormatter(rate.price)}</p>
                          <p>تومان</p>
                        </div>
                        {rate.description && (
                          <p className="text-neutral-500 mr-5 text-sm">
                            {rate.description}
                          </p>
                        )}
                      </div>
                    ))}
                  </RadioGroup>
                </>
              ) : (
                <>
                  <div className="flex items-center justify-center">
                    <p>هیچ نحوه ارسالی برای انتخاب وجود ندارد</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <OrderSummary
          addressId={selectedAddress?.id}
          customerId={customer.id}
          shippingRate={selectedShippingRate}
          cartItems={cartItems}
        />
      </div>
      <div className="w-full bg-white border-t lg:hidden p-4 flex items-center justify-between fixed bottom-0">
        <Link
          href="/"
          className={cn(
            buttonVariants({ variant: "default" }),
            "bg-primaryColor w-[200px] hover:bg-primaryColor/90"
          )}
        >
          ثبت سفارش
        </Link>
        <div className="flex flex-col justify-center gap-y-1">
          <p className="text-sm text-neutral-500">مبلغ قابل پرداخت</p>
          <p>{priceFormatter(totalPrice)}</p>
        </div>
      </div>
    </>
  )
}

export default ShippingClient
