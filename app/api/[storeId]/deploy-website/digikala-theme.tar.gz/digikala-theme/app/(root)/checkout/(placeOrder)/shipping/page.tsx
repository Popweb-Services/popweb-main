import { Metadata } from "next"
import { redirect } from "next/navigation"
import { getAddresses } from "@/actions/get-addresses"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import { getCustomer } from "@/actions/get-customer"
import { getShippingRates } from "@/actions/get-shipping-rates"
import { getStore } from "@/actions/get-store"

import { getAuthSession } from "@/lib/session"
import CreateAddressModal from "@/components/ui/modals/create-address-modal"

import ShippingClient from "./shipping-client"

interface ShippingPageProps {}

export async function generateMetadata(): Promise<Metadata> {
  const store = await getStore()
  return {
    title: `${store.name} - نحوه ارسال سفارش`,
    description: store.description,
    alternates: {
      canonical: "/checkout/cart",
    },
  }
}

const ShippingPage = async ({}) => {
  const session = await getAuthSession()
  const addresses = await getAddresses(session?.user.id!)
  const cartItems = await getCartItemsByCustomerId(session?.user.id!)
  if (cartItems.length === 0) {
    return redirect("/checkout/cart")
  }
  const customer = await getCustomer(session?.user.id!)
  const shippingRates = await getShippingRates()
  // await new Promise((resolve) => setTimeout(resolve, 100000))
  return (
    <>
      <CreateAddressModal customer={customer} />
      <ShippingClient
        shippingRates={shippingRates}
        customer={customer}
        addresses={addresses}
        cartItems={cartItems}
      />
    </>
  )
}

export default ShippingPage
