import { Suspense } from "react"
import { RadioGroup } from "@radix-ui/react-dropdown-menu"
import { RadioGroupItem } from "@radix-ui/react-radio-group"
import { InfoIcon } from "lucide-react"
import { GrCreditCard } from "react-icons/gr"
import { TbTruck } from "react-icons/tb"

import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import OrderSummary from "@/components/order-summary"

interface PaymentPageLoadingProps {}

const PaymentPageLoading: React.FC<PaymentPageLoadingProps> = ({}) => {
  return (
    <>
      <div className="grid grid-cols-4 max-lg:grid-cols-1 gap-2 mt-4 ">
        <div className="col-span-3 space-y-4 bg-white max-lg:col-span-1 ">
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <Skeleton className="w-[150px] h-4" />
            <div className="flex flex-col py-4 gap-y-1">
              <div className="flex items-center gap-x-4">
                <Skeleton className="w-4 h-4" />
                <Skeleton className="w-6 h-6" />
                <Skeleton className="w-[110px] h-4" />
              </div>
              <Skeleton className="mr-16 w-[160px] h-4" />
            </div>
          </div>
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <Skeleton className="w-[80px] h-4" />
            <div className="">
              <div className="pt-6 flex items-center gap-x-3">
                <Skeleton className="w-5 h-5" />
                <Skeleton className="w-[80px] h-3" />
              </div>
              <Skeleton className="w-[110px] h-4 mt-3 " />
            </div>
            <Skeleton className="w-[70px] h-4" />
            <div className="grid pt-4 gap-x-2 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8">
              {[...Array(8)].map((item) => (
                <div className="flex flex-col gap-y-1">
                  <Skeleton className="w-full aspect-square" />
                  <div className="flex items-center justify-center">
                    <Skeleton className="w-full h-4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <div className="flex text-neutral-500 items-center gap-x-3">
              <Skeleton className="w-4 h-4" />
              <Skeleton className="w-[300px] h-4" />
            </div>
          </div>
        </div>
        <div className="max-lg:hidden h-[170px] w-full p-4 space-y-2 border rounded-lg">
          {[...Array(3)].map((item) => (
            <>
              <div className="flex items-center justify-between">
                <Skeleton className="w-[60px] h-4" />
                <Skeleton className="w-[100px] h-4" />
              </div>
              <Separator />
            </>
          ))}
          <Skeleton className="w-full h-10" />
        </div>
      </div>
    </>
  )
}

export default PaymentPageLoading
