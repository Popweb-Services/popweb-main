import { Skeleton } from "@/components/ui/skeleton"

interface HomePageLoadingProps {}

const HomePageLoading: React.FC<HomePageLoadingProps> = ({}) => {
  return (
    <>
      <div className="pt-[105px]">
        <div className="container">
          <Skeleton className="w-full aspect-[1.5]" />
        </div>
      </div>
    </>
  )
}

export default HomePageLoading
