import Image from "next/image"
import Link from "next/link"
import { redirect } from "next/navigation"
import axios from "axios"

import { Order } from "@/types/order"
import {
  TransactionInfoResponse,
  VerifyTransactionResponse,
} from "@/types/vandar"
import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"

interface SuccessPageProps {
  searchParams: {
    [key: string]: string
  }
}

const SuccessPage = async ({ searchParams }: SuccessPageProps) => {
  try {
    const { data: order } = await axios.get<Order>(
      `${process.env.NEXT_PUBLIC_API_URL}/orders/${searchParams.orderId}`
    )
    const { data: transactionInfo } = await axios.post<TransactionInfoResponse>(
      "https://ipg.vandar.io/api/v3/transaction",
      {
        api_key: process.env.VANDAR_API_KEY,
        token: searchParams.token,
      }
    )
    if (transactionInfo.code === 2) {
      return redirect("/")
    }
    const { data: verifyTransactionResponse } =
      await axios.post<VerifyTransactionResponse>(
        "https://ipg.vandar.io/api/v3/verify",
        {
          api_key: process.env.VANDAR_API_KEY,
          token: searchParams.token,
        }
      )
    console.log(verifyTransactionResponse)
    if (verifyTransactionResponse.status === 1) {
      // update order to paid
      await axios.patch(
        `${process.env.NEXT_PUBLIC_API_URL}/orders/${searchParams.orderId}`,
        { api_key: process.env.VANDAR_API_KEY, token: searchParams.token }
      )
    } else {
      redirect("/")
    }
  } catch (error) {
    console.log("[VERIFY_TRANSACTION]", error)
    redirect("/checkout/failed")
  }
  return (
    <>
      <div dir="rtl" className="container p-6 mx-auto">
        <div className="w-full p-4 rounded-lg border">
          <div className="flex  max-md:flex-col-reverse items-center justify-between">
            <div className="space-y-3">
              <p className="text-2xl text-emerald-700 ">
                سفارش شما با موفقیت ثبت گردید.
              </p>
              <div className="flex items-center gap-x-2">
                <p className="text-neutral-500">شماره سفارش :</p>
                <p>6985420</p>
              </div>
              <div className="flex items-center gap-x-2">
                <p className="text-neutral-500">روش پرداخت :</p>
                <p>پرداخت اینترنتی</p>
              </div>
            </div>
            <div className="relative w-[150px] aspect-square">
              <Image
                alt="illustration"
                width={150}
                height={150}
                src={"/images/shopping-bag-success.png"}
                className="grayscale"
              />
              <Image
                alt="illustration"
                width={80}
                height={80}
                src={"/images/green-check.png"}
                className="absolute -bottom-1 -left-2"
              />
            </div>
          </div>
          <div className="flex items-center gap-x-3">
            <Link
              href={"/profile/orders"}
              className={cn(
                buttonVariants({ variant: "default" }),
                "bg-primaryColor  hover:bg-primaryColor/90"
              )}
            >
              پیگیری سفارش
            </Link>
            <Link
              href={"/"}
              className={cn(
                buttonVariants({ variant: "ghost" }),
                "text-primaryColor"
              )}
            >
              بازگشت به فروشگاه
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}

export default SuccessPage
