import { Suspense } from "react"
import type { Metadata, ResolvingMetadata } from "next"
import Image from "next/image"
import Link from "next/link"
import { getBanner } from "@/actions/get-banner"
import getDiscountedProducts from "@/actions/get-discounted-products"
import { getFeaturedProducts } from "@/actions/get-featured-products"
import { getProducts } from "@/actions/get-products"
import { getStore } from "@/actions/get-store"
import { ArrowLeftCircle } from "lucide-react"

import ProductCard from "@/components/ui/product-card"
import ProductCardSkeleton from "@/components/ui/product-card-skeleton"
import { ScrollArea } from "@/components/ui/scroll-area"
import DiscountedProductsSlider from "@/components/discounted-products-slider"

interface HomePageProps {}

const revalidate = 0

export async function generateMetadata(): Promise<Metadata> {
  const store = await getStore()
  return {
    title: `فروشگاه اینترنتی ${store.name}`,
    description: store.description,
    alternates: {
      canonical: "/",
    },
  }
}

const HomePage = async ({}) => {
  const store = await getStore()
  const featuredProducts = await getFeaturedProducts()
  const discountedProducts = await getDiscountedProducts()
  return (
    <>
      <div className="w-full pt-[105px]">
        {store.bannerUrl && (
          <section className="container relative mt-6 h-auto w-full max-md:p-0 overflow-hidden bg-transparent">
            <Image
              priority
              src={store.bannerUrl}
              alt="banner"
              width={5000}
              height={100}
              className="h-auto w-full overflow-hidden rounded-lg object-cover max-md:rounded-none"
            />
          </section>
        )}
        <section>
          <div className="container">
            {discountedProducts.length > 0 && (
              <DiscountedProductsSlider products={discountedProducts} />
            )}
          </div>
        </section>
        <div className="container mt-10 box-border grid border-collapse grid-cols-2  md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">
          {featuredProducts &&
            featuredProducts.map((product) => (
              <Suspense fallback={<ProductCardSkeleton />}>
                <ProductCard key={product.id} product={product} />
              </Suspense>
            ))}
        </div>
      </div>
    </>
  )
}

export default HomePage
