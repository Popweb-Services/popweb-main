import { ReactNode, Suspense } from "react"
import { cookies } from "next/headers"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import getCartItemsByDeviceId from "@/actions/get-cart-items-by-device-id"
import { getCategories } from "@/actions/get-categories"
import { getStore } from "@/actions/get-store"

import { CartItem } from "@/types/products"
import { getAuthSession } from "@/lib/session"
import Footer from "@/components/footer"
import MobileBottomNav from "@/components/mobile-bottom-nav"
import Navbar from "@/components/navbar"

interface RootLayoutProps {
  children: ReactNode
}

const RootLayout = async ({ children }: RootLayoutProps) => {
  const store = await getStore()

  const session = await getAuthSession()
  const categories = await getCategories()
  const deviceId = cookies().get("device_id")?.value
  let cartItems: CartItem[] = []
  if (deviceId && !session) {
    cartItems = await getCartItemsByDeviceId(deviceId)
  } else if (session) {
    cartItems = await getCartItemsByCustomerId(session?.user.id)
  }
  return (
    <>
      <Navbar
        cartItems={cartItems}
        session={session}
        store={store}
        categories={categories}
      />
      {children}
      <MobileBottomNav session={session} cartItems={cartItems} />
      <Footer store={store} />
    </>
  )
}

export default RootLayout
