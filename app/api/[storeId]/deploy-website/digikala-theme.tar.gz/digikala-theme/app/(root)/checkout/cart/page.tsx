import { Metadata, ResolvingMetadata } from "next"
import { cookies } from "next/headers"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import getCartItemsById from "@/actions/get-cart-items-by-device-id"
import getCartItemsByDeviceId from "@/actions/get-cart-items-by-device-id"
import { getStore } from "@/actions/get-store"

import { CartItem } from "@/types/products"
import { getAuthSession } from "@/lib/session"
import { Separator } from "@/components/ui/separator"

import CartClient from "./components/cart-client"

interface CartPageProps {}

export const revalidate = 0

export async function generateMetadata(): Promise<Metadata> {
  const session = await getAuthSession()
  const store = await getStore()
  return {
    title: `فروشگاه اینترنتی ${store.name}`,
    description: store.description,
    alternates: {
      canonical: "/checkout/cart",
    },
  }
}

const CartPage = async ({}) => {
  const session = await getAuthSession()
  let cartItems: CartItem[] = []
  const deviceId = cookies().get("device_id")?.value
  if (deviceId) {
    cartItems = await getCartItemsByDeviceId(deviceId)
  } else if (!deviceId && session?.user.id) {
    cartItems = await getCartItemsByCustomerId(session?.user.id)
  }
  return (
    <>
      <div dir="rtl" className="container pt-[100px] max-lg:px-0">
        <h2 className="text-lg font-bold max-md:px-2">سبد خرید</h2>
        <Separator className="mt-2" />
        <CartClient session={session} cartItems={cartItems} />
      </div>
    </>
  )
}

export default CartPage
