"use client"

import path from "path"
import { Suspense, useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { template } from "lodash"
import { Trash2 } from "lucide-react"
import { Session } from "next-auth"
import { useCookies } from "react-cookie"
import { AiOutlineLeft } from "react-icons/ai"
import { ImSpinner8 } from "react-icons/im"
import { RiShoppingBasket2Line } from "react-icons/ri"
import { TbLogin } from "react-icons/tb"

import { CartItem as CartItemType } from "@/types/products"
import { priceFormatter } from "@/lib/formatter"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { Button, buttonVariants } from "@/components/ui/button"
import CartItem from "@/components/ui/cart-item"
import CartItemLoading from "@/components/ui/cart-item-loading"
import QuantityButton from "@/components/ui/quantity-button"
import { Separator } from "@/components/ui/separator"

interface CartClientProps {
  cartItems: CartItemType[]
  session: Session | null
}

const CartClient: React.FC<CartClientProps> = ({ cartItems, session }) => {
  const { toast } = useToast()
  const router = useRouter()
  const [cartQuantityCount, setCartQuantityCount] = useState<number>()
  const [totalPrice, setTotalPrice] = useState<number>(0)
  const [totalBasketPrice, setTotalBasketPrice] = useState<number>(0)
  const pathname = usePathname()
  const [isMounted, setIsMounted] = useState(false)
  const [cookies, setCookie] = useCookies(["device_id"])
  const { mutate: deleteAllCartItems, isLoading: isDeletingAllCartItems } =
    useMutation({
      mutationFn: async () => {
        if (session?.user) {
          await axios.delete(
            `${process.env.NEXT_PUBLIC_API_URL}/cart?customerId=${session.user.id}`
          )
        } else {
          await axios.delete(
            `${process.env.NEXT_PUBLIC_API_URL}/cart?deviceId=${cookies.device_id}`
          )
        }
      },
      onError: () => {
        toast({
          description: "خطایی پیش آمد لطفا بعدا تلاش کنید.",
          variant: "destructive",
        })
      },
      onSuccess: () => {
        router.refresh()
      },
    })
  useEffect(() => {
    setIsMounted(true)
  }, [])
  useEffect(() => {
    const count = cartItems.reduce((acc, item) => {
      return acc + item.quantity
    }, 0)
    setCartQuantityCount(count)
    const totalProductPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        return acc + item.variant.price * item.quantity
      } else {
        return acc + item.product.price * item.quantity
      }
    }, 0)
    setTotalPrice(totalProductPrice)
    const totalProductBasketPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        if (item.variant.priceAfterDiscount) {
          return acc + item.variant.priceAfterDiscount * item.quantity
        } else {
          return acc + item.variant.price * item.quantity
        }
      } else {
        if (item.product.priceAfterDiscount) {
          return acc + item.product.priceAfterDiscount * item.quantity
        } else {
          return acc + item.product.price * item.quantity
        }
      }
    }, 0)
    setTotalBasketPrice(totalProductBasketPrice)
  }, [cartItems])
  if (!isMounted) {
    return null
  }
  return (
    <>
      <div className="relative grid grid-cols-4 gap-8 py-4 max-md:grid-cols-1">
        {cartItems.length === 0 ? (
          <div className="col-span-3 flex min-h-[320px] w-full flex-col items-center justify-center rounded-lg border max-md:order-2 max-md:col-span-1 max-md:border-none">
            <RiShoppingBasket2Line className="h-[150px] w-[150px] text-neutral-400" />
            <p className="text-lg font-bold">سبد خرید شما خالی است !</p>
          </div>
        ) : (
          <div className="col-span-3 flex flex-col rounded-lg border max-md:col-span-1 max-md:rounded-none max-md:border-0">
            <div className="items-centr flex justify-between p-3">
              <div className="flex items-center gap-x-2 text-sm text-neutral-500">
                <p>{cartQuantityCount}</p>
                <p>کالا</p>
              </div>
              <button
                onClick={() => {
                  deleteAllCartItems()
                }}
                className="flex items-center gap-x-2 text-sm text-rose-500"
              >
                {isDeletingAllCartItems ? (
                  <ImSpinner8 className="animate-spin" />
                ) : (
                  <>
                    <Trash2 className="h-4 w-4" />
                    <p>حذف همه</p>
                  </>
                )}
              </button>
            </div>
            {cartItems
              .map((cartItem) => (
                <Suspense fallback={<CartItemLoading />}>
                  <CartItem key={cartItem.id} cartItem={cartItem} />
                </Suspense>
              ))
              .reverse()}
          </div>
        )}
        {!session && cartItems.length === 0 && (
          <div
            onClick={() => {
              router.push(`/sign-in?callback=${pathname}`)
            }}
            className="md:h-[150px\] mx-auto w-[95%] cursor-pointer space-y-2 rounded-lg border p-4 transition-shadow hover:shadow-md"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-x-2">
                <TbLogin />
                <p className="text-lg font-bold">ورود به حساب کاربری</p>
              </div>
              <AiOutlineLeft />
            </div>
            <p className="text-sm font-medium text-neutral-500">
              برای مشاهده محصولاتی که پیش تر به سبد خرید خود اضافه کرده اید وارد
              شوید.
            </p>
          </div>
        )}
        {cartItems.length !== 0 && (
          <div className="">
            <div className="sticky top-20 w-full space-y-2 rounded-lg border p-4 transition-shadow max-md:block  max-md:border-none">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-x-2 text-sm">
                  <p>قیمت کالاها</p>
                  <p>({cartQuantityCount})</p>
                </div>
                <div className="flex items-center gap-x-2">
                  <p>{priceFormatter(totalPrice)}</p>
                  <p>تومان</p>
                </div>
              </div>
              {cartItems.filter(
                (item) =>
                  item.variant?.priceAfterDiscount ||
                  item.product.priceAfterDiscount
              ).length > 0 && (
                <div className="flex items-center justify-between text-sm text-primaryColor">
                  <p>تخفیف</p>
                  <div className="flex items-center gap-x-2">
                    {Math.floor(
                      ((totalPrice - totalBasketPrice) / totalPrice) * 100
                    ) > 1 && (
                      <p>
                        (
                        {Math.floor(
                          ((totalPrice - totalBasketPrice) / totalPrice) * 100
                        )}
                        %)
                      </p>
                    )}

                    <p>{priceFormatter(totalPrice - totalBasketPrice)}</p>
                    <p>تومان</p>
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between text-sm font-bold">
                <p>جمع سبد خرید</p>
                <div className="flex items-center gap-x-2">
                  <p>{priceFormatter(totalBasketPrice)}</p>
                  <p>تومان</p>
                </div>
              </div>

              <Link
                href={
                  session
                    ? "/checkout/shipping"
                    : "/sign-in?backUrl=/checkout/shipping"
                }
                className={cn(
                  buttonVariants({ variant: "default" }),
                  "w-full bg-primaryColor hover:bg-primaryColor/90 max-md:hidden"
                )}
              >
                ثبت سفارش
              </Link>
            </div>
            <p className="sticky top-[250px] mt-2 text-xs text-neutral-500 max-md:block max-md:px-4 ">
              هزینه این سفارش هنوز پرداخت نشده‌ و در صورت اتمام موجودی، کالاها
              از سبد حذف می‌شوند
            </p>
          </div>
        )}
      </div>
      {/* mobile bottom cart nav */}
      {cartItems.length > 0 && (
        <div className="fixed bottom-[50px] z-10 flex w-full items-center justify-between border-t bg-white p-2 md:hidden">
          <Link
            href={
              session
                ? "/checkout/shipping"
                : `/sign-in?backUrl=/checkout/shipping`
            }
            className={cn(
              buttonVariants({ variant: "default" }),
              "w-[250px] bg-primaryColor hover:bg-primaryColor/90"
            )}
          >
            ثبت سفارش
          </Link>
          <div className="flex flex-col justify-center gap-y-1">
            <p className="text-sm text-neutral-500">جمع سبد خرید</p>
            <div className="flex items-center gap-x-2">
              <p>{priceFormatter(totalBasketPrice)}</p>
              <p>تومان</p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default CartClient
