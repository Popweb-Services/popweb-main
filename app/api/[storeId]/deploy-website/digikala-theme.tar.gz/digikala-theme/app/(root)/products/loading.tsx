import { Skeleton } from "@/components/ui/skeleton"

interface ProductsLoadingPageProps {}

const ProductsLoadingPage: React.FC<ProductsLoadingPageProps> = ({}) => {
    
  return (
    <>
 
      <div className="pt-[120px] max-lg:pt-[65px] container">
        <Skeleton className="w-full rounded-lg h-[104px]" />
        <div className="w-full grid grid-cols-4">
            <div className="p-4">
                
            </div>
            <div className="col-span-3"></div>
        </div>
      </div>
    </>
  )
}

export default ProductsLoadingPage
