"use client"

import { Suspense, useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import getCartItemsByCustomerId from "@/actions/get-cart-items-by-customer-id"
import { InfoIcon } from "lucide-react"
import { Session } from "next-auth"
import { AiOutlineLeft } from "react-icons/ai"
import { GrCreditCard, GrLocation } from "react-icons/gr"
import { MdOutlineAddLocation } from "react-icons/md"
import { TbTruck } from "react-icons/tb"

import { Address } from "@/types/address"
import { Customer } from "@/types/customer"
import { CartItem } from "@/types/products"
import { ShippingRate } from "@/types/shipping-rate"
import { priceFormatter } from "@/lib/formatter"
import { getAuthSession } from "@/lib/session"
import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import CreateAddressModal from "@/components/ui/modals/create-address-modal"
import QuantityButton from "@/components/ui/quantity-button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import OrderSummary from "@/components/order-summary"
import PaymentPageCartItemsSlider from "@/components/payment-page-cart-items-slider"

interface PaymentClientProps {
  addressId: string
  shippingRate: ShippingRate
  customer: Customer
  cartItems: CartItem[]
}

const PaymentClient: React.FC<PaymentClientProps> = ({
  addressId,
  shippingRate,
  customer,
  cartItems,
}) => {
  const [totalPrice, setTotalPrice] = useState(0)
  useEffect(() => {
    const totalBasketPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        if (
          item.variant.priceAfterDiscount &&
          item.variant.priceAfterDiscount > 0 &&
          item.variant.priceAfterDiscount < item.variant.price
        ) {
          return acc + item.variant.priceAfterDiscount * item.quantity
        } else {
          return acc + item.variant.price * item.quantity
        }
      } else {
        if (
          item.product.priceAfterDiscount &&
          item.product.priceAfterDiscount > 0 &&
          item.product.priceAfterDiscount < item.product.price
        ) {
          return acc + item.product.priceAfterDiscount * item.quantity
        } else {
          return acc + item.product.price * item.quantity
        }
      }
    }, 0)
    setTotalPrice(totalBasketPrice + shippingRate.price)
  }, [cartItems])
  return (
    <>
      <div className="grid grid-cols-4 max-lg:grid-cols-1 gap-2 mt-4 max-lg:pb-[100px]">
        <div className="col-span-3 space-y-4 bg-white max-lg:col-span-1 ">
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <p>انتخاب روش پرداخت</p>
            <RadioGroup dir="rtl" defaultValue="debit">
              <div className="flex flex-col py-4 gap-y-1">
                <div className="flex items-center gap-x-4">
                  <RadioGroupItem value="debit" />
                  <GrCreditCard className="w-6 h-6" />
                  <p className="text-lg">پرداخت اینترنتی</p>
                </div>
                <p className="mr-16 text-neutral-500">
                  پرداخت با تمامی کارت های بانکی
                </p>
              </div>
            </RadioGroup>
          </div>
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <p>خلاصه سفارش</p>
            <div className="">
              <div className="pt-6 flex items-center gap-x-3">
                <TbTruck className="w-5 h-5 -scale-x-100 text-primaryColor" />
                <p>{shippingRate.name}</p>
              </div>
              <p className="text-sm text-neutral-500">
                {shippingRate.description}
              </p>
            </div>
            <p className="text-neutral-500 text-sm">جزییات مرسوله</p>
            {/* <div className="grid pt-4 gap-x-2 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8">
              {cartItems.map((item) => (
                <div key={item.id} className="flex flex-col gap-y-1">
                  <div className="w-full aspect-square">
                    <Image
                      priority
                      src={item.product.mainImageUrl}
                      alt="imageurl"
                      width={150}
                      height={150}
                      className="object-cover w-full h-full"
                    />
                  </div>

                  {item.variant?.options.map((option) => {
                    const productOption = item.product.options?.find((item) =>
                      item.values.includes(option)
                    )
                    return (
                      <div
                        key={option}
                        className="flex items-center justify-center gap-x-2 text-sm text-neutral-500"
                      >
                        <p>{productOption?.name}</p>
                        <p>:</p>
                        <p>{option}</p>
                      </div>
                    )
                  })}
                </div>
              ))}
            </div> */}
            <PaymentPageCartItemsSlider cartItems={cartItems} />
          </div>
          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <div className="flex text-neutral-500 items-center gap-x-3">
              <InfoIcon className="w-4 h-4" />
              <p className="text-sm">
                برای دریافت فاکتور، بعد از دریافت سفارش به حساب کاربری و صفحه
                جزئیات سفارش سر بزنید
              </p>
            </div>
          </div>
        </div>
        <Suspense fallback={"loading"}>
          <OrderSummary
            customerPhone={customer.phone}
            customerId={customer.id}
            addressId={addressId}
            shippingRate={shippingRate}
            cartItems={cartItems}
          />
        </Suspense>
      </div>
      <div className="w-full bg-white border-t lg:hidden p-4 flex items-center justify-between fixed bottom-0">
        <Link
          href="/"
          className={cn(
            buttonVariants({ variant: "default" }),
            "bg-primaryColor w-[200px] hover:bg-primaryColor/90"
          )}
        >
          پرداخت
        </Link>
        <div className="flex flex-col justify-center gap-y-1">
          <p className="text-sm text-neutral-500">مبلغ قابل پرداخت</p>
          <p>{priceFormatter(totalPrice)}</p>
        </div>
      </div>
    </>
  )
}

export default PaymentClient
