import { AiOutlineLeft } from "react-icons/ai"
import { GrLocation } from "react-icons/gr"
import { MdOutlineAddLocation } from "react-icons/md"
import { TbTruck } from "react-icons/tb"

import QuantityButton from "@/components/ui/quantity-button"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"

interface ShippingLoadingProps {}

const ShippingLoading: React.FC<ShippingLoadingProps> = ({}) => {
  return (
    <>
      <div className="grid grid-cols-4 max-md:grid-cols-1 gap-2 mt-4 max-md:bg-neutral-100">
        <div className="col-span-3 space-y-4 bg-white max-md:col-span-1 max-md:bg-neutral-200">
          <div className="flex flex-col max-md:rounded-none max-md:border-none bg-white p-4 gap-x-2 border rounded-lg">
            <div className="flex items-center bg-white">
              <Skeleton className="mx-4 w-6 h-6" />
              <div className="space-y-2">
                <Skeleton className="w-[80px] h-4" />
                <Skeleton className="w-[300px] h-4" />
                <Skeleton className="w-[200px] h-4" />
              </div>
            </div>

            <div className="flex justify-end text-primaryColor bottom-5 left-5 items-center gap-x-2">
              <div className="flex items-center gap-x-2 cursor-pointer">
                <Skeleton className="w-[110px] h-4" />
              </div>
            </div>
          </div>

          <div className="w-full border bg-white max-md:rounded-none space-y-4 rounded-lg p-4">
            <Skeleton className="w-[60px] h-4" />
            <div className="grid gap-x-2 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8">
              {[...Array(8)].map((item) => (
                <div className="flex flex-col gap-y-1">
                  <Skeleton className="w-full aspect-square" />
                  <div className="flex items-center justify-center">
                    <Skeleton className="w-full h-[40px]" />
                  </div>
                  <Skeleton className="w-full h-4" />
                </div>
              ))}
            </div>
            <div className="flex items-center gap-x-2">
              <Skeleton className="w-5 h-5" />
              <Skeleton className="w-[100px] h-4" />
            </div>
            <div className="w-full divide-y-2 border rounded-lg p-4">
              {[...Array(4)].map((item) => (
                <div className="flex flex-col py-2 gap-y-2">
                  <div className="flex items-center gap-x-3">
                    <Skeleton className="w-4 h-4" />
                    <Skeleton className="w-[120px] h-4" />
                  </div>

                  <Skeleton className="w-[80px] h-4" />
                  <Skeleton className="w-[140px] h-4" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="max-lg:hidden h-[170px] w-full p-4 space-y-2 border rounded-lg">
          {[...Array(3)].map((item) => (
            <>
              <div className="flex items-center justify-between">
                <Skeleton className="w-[60px] h-4" />
                <Skeleton className="w-[100px] h-4" />
              </div>
              <Separator />
            </>
          ))}
          <Skeleton className="w-full h-10" />
        </div>
      </div>
    </>
  )
}

export default ShippingLoading
