import { ReadonlyURLSearchParams } from "next/navigation"
import { String } from "lodash"

const generateQueryString = (searchParams: { [key: string]: string }) => {
  const params = new URLSearchParams(searchParams)
  if (searchParams.cheapest === "true") {
    params.set("cheapest", searchParams.cheapest)
  }
  return params.toString()
}
export default generateQueryString
