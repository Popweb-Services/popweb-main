import axios from "axios"
import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        phone: { label: "phone", type: "string" },
        otp: { label: "otp", type: "password" },
      },
      async authorize(credentials) {
        try {
          if (!credentials?.otp || !credentials.phone) {
            throw new Error("otp or phone is incorrect")
          }
          const { data } = await axios.post(
            `${process.env.NEXT_PUBLIC_API_URL}/customers/${credentials?.phone}`,
            {
              code: credentials?.otp,
            }
          )
          const user = data as { id: string }
          return user
        } catch (error) {
          console.log(error)
          throw new Error("error happened")
        }
      },
    }),
  ],
  callbacks: {
    session: async ({ session, token, user }) => {
      if (session.user) {
        session.user.id = token.sub!
        session.user.name = token.name
      }
      return session
    },
  },
  debug: process.env.NODE_ENV === "development",
  pages: {
    signIn: "/sign-in",
  },
  session: {
    strategy: "jwt",
  },
}
