import { z } from "zod"

export const phoneNumberValidator = z.object({
  phone: z
    .string()
    .min(1, { message: "این فیلد اجباری است." })
    .regex(/^09\d{9}/g, {
      message: "شماره موبایل نا معتبر میباشد.",
    }),
})

export const verifyCodeValidator = z.object({
  code: z.string(),
})
