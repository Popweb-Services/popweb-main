import { z } from "zod"

const paymentTokenRequestDataValidator = z.object({
  amount: z.number().min(1000),
  mobile_number: z.string(),
  orderId: z.string(),
})

export default paymentTokenRequestDataValidator
