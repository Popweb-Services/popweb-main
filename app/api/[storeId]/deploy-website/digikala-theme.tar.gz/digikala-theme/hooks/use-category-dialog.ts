import { create } from "zustand"

interface CategoryDialogStore {
  isOpen: boolean
  onOpen: () => void
  onClose: () => void
}

const useCategoryDialog = create<CategoryDialogStore>((set) => ({
  isOpen: false,
  onClose: () => set({ isOpen: false }),
  onOpen: () => set({ isOpen: true }),
}))
export default useCategoryDialog
