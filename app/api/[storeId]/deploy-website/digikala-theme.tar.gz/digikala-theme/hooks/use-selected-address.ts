import { create } from "zustand"

import { Address } from "@/types/address"

interface SelectedAddressStore {
  selectedAddress: Address | undefined
  setAddress: (address: Address) => void
}

const useSelectedAddress = create<SelectedAddressStore>((set) => ({
  selectedAddress: undefined,
  setAddress: (address) => set({ selectedAddress: address }),
}))

export default useSelectedAddress
