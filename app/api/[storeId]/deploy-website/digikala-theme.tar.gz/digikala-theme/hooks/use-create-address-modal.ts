import { create } from "zustand"

import { Address } from "@/types/address"

interface CreateAddressStore {
  isOpen: boolean
  onOpen: () => void
  onClose: () => void
  address?: Address
  setAddress: (address: Address) => void
}

const useCreateAddressModal = create<CreateAddressStore>((set) => ({
  isOpen: false,
  onOpen: () => set({ isOpen: true }),
  onClose: () => set({ isOpen: false }),
  setAddress: (address) => set({ address }),
}))

export default useCreateAddressModal