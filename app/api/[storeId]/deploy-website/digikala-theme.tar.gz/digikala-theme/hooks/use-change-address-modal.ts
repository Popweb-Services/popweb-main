import { create } from "zustand"

import { Address } from "@/types/address"

interface ChangeAddressModalStore {
  isOpen: boolean
  onOpen: () => void
  onClose: () => void
  addresses: Address[]
  setAddresses: (addresses: Address[]) => void
}

const useChangeAddressModal = create<ChangeAddressModalStore>((set) => ({
  isOpen: false,
  onOpen: () => set({ isOpen: true }),
  onClose: () => set({ isOpen: false }),
  addresses: [],
  setAddresses: (addresses) => set({ addresses: addresses }),
}))

export default useChangeAddressModal
