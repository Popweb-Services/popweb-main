"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home } from "lucide-react"
import { Session } from "next-auth"
import {
  BiCategoryAlt,
  BiSolidCategoryAlt,
  BiSolidUser,
  BiUser,
} from "react-icons/bi"
import { RiShoppingCartFill, RiShoppingCartLine } from "react-icons/ri"
import { TiHome, TiHomeOutline } from "react-icons/ti"

import { CartItem } from "@/types/products"
import { cn } from "@/lib/utils"

import Icon from "./ui/icon"

interface MobileBottomNavProps {
  cartItems: CartItem[]
  session: Session | null
}

const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  cartItems,
  session,
}) => {
  const pathname = usePathname()
  const [itemCount, setItemsCount] = useState<number>(0)
  useEffect(() => {
    const count = cartItems.reduce((acc, item) => {
      return acc + item.quantity
    }, 0)
    setItemsCount(count)
  }, [cartItems])
  const mobileBottomNav = [
    {
      icon: TiHomeOutline,
      activeIcon: TiHome,
      label: "خانه",
      href: "/",
      active: pathname === "/",
    },
    {
      icon: BiCategoryAlt,
      activeIcon: BiSolidCategoryAlt,
      label: "دسته بندی",
      href: "/categories",
      active: pathname === "/categories",
    },
    {
      icon: RiShoppingCartLine,
      activeIcon: RiShoppingCartFill,
      label: "سبد خرید",
      href: "/checkout/cart",
      active: pathname === "/checkout/cart",
    },
  ]
  if (pathname === "/checkout/shipping") {
    return null
  }
  if (pathname === "/checkout/payment") {
    return null
  }
  return (
    <>
      <div
        dir="rtl"
        className="fixed bottom-0 z-10 grid h-14 w-full grid-cols-4 border-t-2  bg-white text-neutral-500  md:hidden"
      >
        {mobileBottomNav.map((route) => (
          <Link
            key={route.href}
            href={route.href}
            className="flex h-full flex-col items-center justify-center rounded-lg px-4 py-2 hover:bg-secondary"
          >
            <div className="relative">
              {route.href === "/checkout/cart" && itemCount > 0 && (
                <div className="text-xs absolute -right-1 bottom-0 flex h-4 w-4 scale-75 items-center justify-center rounded-sm bg-primaryColor text-white ring-2 ring-white">
                  {itemCount}
                </div>
              )}
              {route.active ? (
                <Icon className="h-6 w-6" icon={route.activeIcon} />
              ) : (
                <Icon className="h-6 w-6" icon={route.icon} />
              )}
            </div>

            <p
              className={cn(
                route.active ? "font-bold" : "font-medium",
                "text-center text-xs sm:text-sm"
              )}
            >
              {route.label}
            </p>
          </Link>
        ))}
        <Link
          href={session ? "/profile" : `/sign-in?backUrl=${pathname}`}
          className="flex h-full flex-col items-center justify-center rounded-lg px-4 py-2 hover:bg-secondary"
        >
          <div className="relative">
            {pathname === "/profile" ? (
              <Icon className="h-6 w-6" icon={BiUser} />
            ) : (
              <Icon className="h-6 w-6" icon={BiSolidUser} />
            )}
          </div>

          <p
            className={cn(
              pathname === "/profile" ? "font-bold" : "font-medium",
              "text-center text-xs sm:text-sm"
            )}
          >
            حساب کاربری
          </p>
        </Link>
      </div>
    </>
  )
}

export default MobileBottomNav
