"use client"

import { useState } from "react"
import { cookies } from "next/headers"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"
import getCartItemsByDeviceId from "@/actions/get-cart-items-by-device-id"
import { getCategories } from "@/actions/get-categories"
import { getLogo } from "@/actions/get-logo"
import { getStore } from "@/actions/get-store"
import { Search } from "lucide-react"
import { Session } from "next-auth"
import { getSession } from "next-auth/react"
import { IoEnterOutline } from "react-icons/io5"
import { RiShoppingCartLine } from "react-icons/ri"

import { CartItem, Category } from "@/types/products"
import { Store } from "@/types/store"
import { getAuthSession } from "@/lib/session"
import { cn } from "@/lib/utils"
import useCategoryDialog from "@/hooks/use-category-dialog"

import CategoriesNavigationMenu from "./categories-navigation-menu"
import DesktopCartBotton from "./desktop-cart-button"
import SearchBar from "./desktop-search-bar"
import { Button } from "./ui/button"
import UserAccountNav from "./user-account-nav"

interface NavbarProps {
  session: Session | null
  store: Store
  categories: Category[]
  cartItems: CartItem[]
}

export const revalidate = 0

const Navbar: React.FC<NavbarProps> = ({
  session,
  store,
  cartItems,
  categories,
}) => {
  const [scrollY, setScrollY] = useState(window.scrollY)
  const [isNavHidden, setIsNavHidden] = useState(false)
  const handleNavigation = () => {
    setScrollY(window.scrollY)
    if (scrollY > window.scrollY) {
      setIsNavHidden(false)
    } else {
      setIsNavHidden(true)
    }
  }
  window.addEventListener("scroll", handleNavigation)
  const pathname = usePathname()
  if (pathname === "/checkout/shipping") {
    return null
  }
  if (pathname === "/checkout/payment") {
    return null
  }
  if (pathname === "/checkout/success") {
    return null
  }
  return (
    <>
      <header
        dir="rtl"
        className="fixed h-[65px] z-50 w-full bg-white max-lg:border-b"
      >
        <div className="mx-auto flex h-full flex-col py-3 md:container max-md:px-2">
          <div className="flex items-center justify-between gap-y-2 max-lg:hidden">
            <div className="flex items-center gap-x-3 ">
              <SearchBar storeId={store.id} />
            </div>
            <div className="flex items-center gap-x-3 max-lg:hidden">
              {session?.user ? (
                <UserAccountNav />
              ) : (
                <Link
                  href={`/sign-in?backUrl=${pathname}`}
                  className="flex items-center gap-x-3 rounded-xl border px-4 py-2 transition-colors hover:bg-slate-100"
                >
                  <p>ورود</p>
                  <span className="h-[20px] w-[1px] bg-slate-700"></span>
                  <p>ثبت نام</p>
                </Link>
              )}

              <DesktopCartBotton cartItems={cartItems} session={session} />
            </div>
          </div>

          <div className="flex h-11 w-full cursor-pointer items-center gap-x-2 rounded-xl bg-secondary px-4 text-neutral-500 lg:hidden">
            <Search />
            <p>جستجو در</p>
          </div>
        </div>
      </header>
      {categories.length > 0 && (
        <nav
          dir="rtl"
          className={cn(
            isNavHidden ? "-translate-y-[40px]" : "translate-y-0",
            "max-md:hidden z-40 transition-transform duration-300 w-full fixed top-[65px] shadow-md bg-white"
          )}
        >
          <div className="container flex gap-x-4">
            <CategoriesNavigationMenu categories={categories} />
          </div>
        </nav>
      )}
    </>
  )
}

export default Navbar
