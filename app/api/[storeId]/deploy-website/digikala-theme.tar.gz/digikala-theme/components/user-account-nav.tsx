"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { User } from "lucide-react"
import { signOut } from "next-auth/react"
import   {IconType}  from "react-icons"
import { BiShoppingBag } from "react-icons/bi"
import { HiOutlineLogin } from "react-icons/hi"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import Icon from "./ui/icon"

interface UserAccountNavProps {}

const UserAccountNav: React.FC<UserAccountNavProps> = ({}) => {
  const router = useRouter()
  const userAccountRoutes: { icon: IconType; label: string; href: string }[] = [
    { icon: BiShoppingBag, label: "سفارشات", href: "/profile/orders" },
  ]
  return (
    <>
      <DropdownMenu dir="rtl">
        <DropdownMenuTrigger>
          <User />
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          {userAccountRoutes.map((route) => (
            <DropdownMenuItem key={route.href} dir="rtl">
              <Link
                href={route.href}
                className="flex items-center gap-x-3 text-lg"
              >
                <Icon icon={route.icon} className="h-6 w-6" />
                <p>{route.label}</p>
              </Link>
            </DropdownMenuItem>
          ))}
          <DropdownMenuItem
            onClick={() => {
              signOut()
              router.refresh()
            }}
            className="flex w-full cursor-pointer items-center gap-x-3 pl-6 text-lg"
          >
            <HiOutlineLogin className="h-6 w-6 -scale-x-100" />
            <p>خروج از حساب کاربری</p>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  )
}

export default UserAccountNav
