import { useState } from "react"
import Link from "next/link"
import * as Tabs from "@radix-ui/react-tabs"
import { ArrowLeft } from "lucide-react"

import { Category } from "@/types/products"
import { cn } from "@/lib/utils"

import { ScrollArea } from "./ui/scroll-area"

interface CategoryTabsProps {
  categories: Category[]
}

const CategoryTabs: React.FC<CategoryTabsProps> = ({ categories }) => {
  const [activeTabId, setActiveTabId] = useState(categories[0].id)

  return (
    <>
      <Tabs.Root
        value={activeTabId}
        dir="rtl"
        orientation="vertical"
        className="grid grid-cols-6 gap-6"
      >
        <Tabs.List className="flex h-full flex-col gap-y-3">
          {categories.map((category) => (
            <Tabs.Trigger
              key={category.id}
              onPointerEnter={() => {
                setActiveTabId(category.id)
              }}
              className={cn(
                category.id === activeTabId &&
                  "border-primaryColor bg-primaryColor bg-opacity-10 text-primaryColor",
                "px-3 py-2 border rounded-lg"
              )}
              value={category.id}
            >
              {category.name}
            </Tabs.Trigger>
          ))}
        </Tabs.List>
        <ScrollArea dir="rtl" className="w-full col-span-5 p-4 h-full">
          {categories.map((category) => (
            <Tabs.Content
              key={category.id}
              className="outline-none"
              value={category.id}
            >
              <div className="grid grid-cols-5 gap-4">
                <div className="col-span-5 py-2">
                  <Link
                    href={`/products?category=${category.id}`}
                    className="flex items-center text-sm text-primaryColor gap-x-2"
                  >
                    <p>مشاهده همه ی محصولات</p>
                    <p>{category.name}</p>
                    <ArrowLeft className="w-4 h-4" />
                  </Link>
                </div>
                {category.subcategories?.map((subCategory) => (
                  <div key={category.id} className="flex flex-col">
                    <ul>
                      <li>
                        <Link
                          href={`/products?category=${subCategory.id}`}
                          className="text-md font-semibold hover:text-primaryColor duration-200"
                        >
                          {subCategory.name}
                        </Link>
                      </li>
                      {subCategory.subcategories.map((child) => (
                        <li key={category.id}>
                          <Link
                            href={`/products?category=${child.id}`}
                            className="text-sm text-neutral-500"
                          >
                            {child.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </Tabs.Content>
          ))}
        </ScrollArea>
      </Tabs.Root>
    </>
  )
}

export default CategoryTabs
