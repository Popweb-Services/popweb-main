"use client"

import { Swiper, SwiperSlide } from "swiper/react"

import "swiper/css"
import Image from "next/image"
import { useRouter } from "next/navigation"

import { CartItem, Product } from "@/types/products"

import ProductCard from "./ui/product-card"

interface PaymentPageCartItemsSliderProps {
  cartItems: CartItem[]
}

const PaymentPageCartItemsSlider: React.FC<PaymentPageCartItemsSliderProps> = ({
  cartItems,
}) => {
  const router = useRouter()
  return (
    <>
      <div
        dir="rtl"
        className="relative mx-auto  mt-4 w-full max-w-7xl overflow-hidden rounded-lg py-4 max-xl:rounded-none "
      >
        <Swiper
          allowTouchMove={true}
          observeParents={true}
          observeSlideChildren={true}
          observer={true}
          freeMode={true}
          slidesOffsetAfter={0}
          slidesOffsetBefore={0}
          resizeObserver={true}
          slidesPerView="auto"
          spaceBetween={10}
          direction="horizontal"
          width={undefined}
          height={undefined}
        >
          {cartItems.map((item) => (
            <SwiperSlide style={{ height: "150px", width: "100px" }}>
              <div key={item.id} className="flex flex-col gap-y-1">
                <div className="w-full aspect-square">
                  <Image
                    priority
                    src={item.product.mainImageUrl}
                    alt="imageurl"
                    width={150}
                    height={150}
                    className="object-cover w-full h-full"
                  />
                </div>

                {item.variant?.options.map((option) => {
                  const productOption = item.product.options?.find((item) =>
                    item.values.includes(option)
                  )
                  return (
                    <div
                      key={option}
                      className="flex items-center justify-center gap-x-2 text-sm text-neutral-500"
                    >
                      <p>{productOption?.name}</p>
                      <p>:</p>
                      <p>{option}</p>
                    </div>
                  )
                })}
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </>
  )
}

export default PaymentPageCartItemsSlider
