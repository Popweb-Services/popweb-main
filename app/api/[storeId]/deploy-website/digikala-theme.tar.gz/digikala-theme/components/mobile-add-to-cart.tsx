import { priceFormatter } from "@/lib/formatter"

import { Button } from "./ui/button"
import SaleBadge from "./ui/sale-badge"

interface MobileAddToCartProps {
  price: number
  priceAfterDiscount?: number
}

const MobileAddToCart: React.FC<MobileAddToCartProps> = ({
  price,
  priceAfterDiscount,
}) => {
  return (
    <>
      <div
        dir="rtl"
        className="fixed bottom-[50px] w-full border-t bg-white p-4 shadow-md md:hidden"
      >
        {priceAfterDiscount && (
          <div className="flex items-center justify-end gap-x-2">
            <p className="text-neutral-500 line-through">
              {priceFormatter(price)}
            </p>
            <SaleBadge price={price} priceAfterDiscount={priceAfterDiscount} />
          </div>
        )}
        <div className="flex items-center justify-between">
          <Button className="bg-primaryColor hover:bg-primaryColor/90">افزودن به سبد خرید</Button>

          <div className="flex items-center gap-x-2">
            <p>{priceFormatter(priceAfterDiscount ?? price)}</p>
            <p>تومان</p>
          </div>
        </div>
      </div>
    </>
  )
}

export default MobileAddToCart
