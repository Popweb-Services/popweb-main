"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Session } from "next-auth"
import { RiShoppingCartLine } from "react-icons/ri"

import { CartItem as CartItemType } from "@/types/products"
import { priceFormatter } from "@/lib/formatter"
import { cn } from "@/lib/utils"

import { Button, buttonVariants } from "./ui/button"
import CartItem from "./ui/cart-item"
import { DropdownMenu, DropdownMenuContent } from "./ui/dropdown-menu"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "./ui/navigation-menu"
import { ScrollArea } from "./ui/scroll-area"

interface DesktopCartBottonProps {
  cartItems: CartItemType[]
  session: Session | null
}

const DesktopCartBotton: React.FC<DesktopCartBottonProps> = ({
  session,
  cartItems,
}) => {
  const pathname = usePathname()

  const router = useRouter()
  const [totalBasketPrice, setTotalBasketPrice] = useState(0)
  const [itemsCount, setItemsCount] = useState(0)
  const [isMounted, setIsMounted] = useState(false)
  useEffect(() => {
    const count = cartItems.reduce((acc, item) => {
      return acc + item.quantity
    }, 0)
    setItemsCount(count)
    const totalProductBasketPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        if (item.variant.priceAfterDiscount) {
          return acc + item.variant.priceAfterDiscount * item.quantity
        } else {
          return acc + item.variant.price * item.quantity
        }
      } else {
        if (item.product.priceAfterDiscount) {
          return acc + item.product.priceAfterDiscount * item.quantity
        } else {
          return acc + item.product.price * item.quantity
        }
      }
    }, 0)
    setTotalBasketPrice(totalProductBasketPrice)
  }, [cartItems])
  useEffect(() => {
    setIsMounted(true)
  }, [])
  if (!isMounted) {
    return null
  }
  if (cartItems.length > 0 && pathname !== "/checkout/cart") {
    return (
      <>
        <NavigationMenu>
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuTrigger>
                <Link href={"/checkout/cart"} className="relative">
                  <RiShoppingCartLine className="h-6 w-6 scale-x-[-1]" />
                  {itemsCount > 0 && (
                    <div className="absolute -bottom-1  -right-1 flex h-4 w-4 origin-center scale-90 items-center justify-center rounded-sm bg-primaryColor text-sm text-white ring-2 ring-white">
                      {itemsCount}
                    </div>
                  )}
                  <p className="sr-only">سبد خرید</p>
                </Link>
                <NavigationMenuContent>
                  <div dir="rtl" className="w-[400px] bg-white">
                    <div className="flex w-full items-center gap-x-2 border-b p-2 text-sm text-neutral-500">
                      <p>{itemsCount}</p>
                      <p>کالا</p>
                    </div>
                  </div>
                  <ScrollArea dir="rtl" className="h-[400px] w-full">
                    {cartItems
                      .map((cartItem) => (
                        <CartItem key={cartItem.id} cartItem={cartItem} />
                      ))
                      .reverse()}
                  </ScrollArea>
                  <div
                    dir="rtl"
                    className="flex w-full items-center justify-between border-t bg-white p-3"
                  >
                    <div className="flex flex-col gap-y-1">
                      <p className="text-sm text-neutral-500">
                        مبلغ قابل پرداخت
                      </p>
                      <div className="flex items-center gap-x-2 text-lg font-bold">
                        <p>{priceFormatter(totalBasketPrice)}</p>
                        <p>تومان</p>
                      </div>
                    </div>
                    <Link
                      className={cn(
                        buttonVariants({ variant: "default" }),
                        "bg-primaryColor hover:bg-primaryColor/90"
                      )}
                      href={
                        session
                          ? "/checkout/shipping"
                          : `/sign-in?backUrl=/checkout/shipping`
                      }
                    >
                      ثبت سفارش
                    </Link>
                  </div>
                </NavigationMenuContent>
              </NavigationMenuTrigger>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
      </>
    )
  }
  return (
    <>
      <Link
        href={"/checkout/cart"}
        className={cn(buttonVariants({ variant: "ghost" }), "relative")}
      >
        <RiShoppingCartLine className="h-6 w-6 scale-x-[-1]" />
        {itemsCount > 0 && (
          <div className="absolute bottom-1  right-3 flex h-4 w-4 origin-center items-center justify-center rounded-sm bg-primaryColor text-sm text-white ring-2 ring-white">
            {itemsCount}
          </div>
        )}
        <p className="sr-only">سبد خرید</p>
      </Link>
    </>
  )
}

export default DesktopCartBotton
