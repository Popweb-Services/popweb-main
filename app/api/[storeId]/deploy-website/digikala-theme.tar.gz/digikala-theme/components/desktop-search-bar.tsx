"use client"

import { useCallback, useState } from "react"
import { useRouter } from "next/navigation"
import { useQuery } from "@tanstack/react-query"
import axios from "axios"
import { CommandEmpty, CommandList } from "cmdk"
import debounce from "lodash.debounce"
import { Search, Users, X } from "lucide-react"
import { BiCategoryAlt } from "react-icons/bi"
import { CgSpinner } from "react-icons/cg"

import { Category, Product } from "@/types/products"

import SearchProductSlider from "./search-product-slider"
import { Command, CommandGroup, CommandInput, CommandItem } from "./ui/command"

interface SearchBarProps {
  storeId: string
}

const SearchBar: React.FC<SearchBarProps> = ({ storeId }) => {
  const router = useRouter()
  const [productCategories, setProductCategories] = useState<
    { id: string; name: string }[]
  >([])
  const [results, setResults] = useState<{
    products: Product[]
    categories: Category[]
  }>()
  const [input, setInput] = useState<string>("")
  const {
    data: queryResults,
    refetch,
    isFetched,
    isFetching,
  } = useQuery({
    queryFn: async () => {
      if (!input) return []
      const { data } = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/search?query=${input}
        `
      )
      setResults(data)
      setProductCategories(
        data.products.map((product: Product) => ({
          id: product.category?.id,
          name: product.category?.name,
        }))
      )
      return data as { products: Product[]; categories: Category[] }
    },
    queryKey: ["search-query"],
    enabled: false,
  })
  const request = debounce(() => {
    refetch()
  }, 300)
  const debounceRequest = useCallback(() => {
    request()
  }, [request])
  return (
    <>
      <Command
        dir="rtl"
        className="relative  z-50 w-[600px] overflow-visible rounded-lg bg-secondary"
      >
        <CommandInput
          value={input}
          onValueChange={(text: string) => {
            setInput(text)
            debounceRequest()
          }}
          placeholder="جستجو"
          className="h-10 border-none px-2 outline-none ring-0 focus:border-none focus:outline-none"
        />
        {input?.length > 0 && (
          <CommandList className="absolute inset-x-0 top-full rounded-b-md border bg-white pr-4 shadow-2xl">
            {isFetching ? (
              <div className="flex w-full items-center justify-center py-6">
                <CgSpinner className="h-6 w-6 animate-spin" />
              </div>
            ) : (
              <>
                {(results?.products.length ?? 0) > 0 && (
                  <SearchProductSlider
                    onProductSelect={() => setInput("")}
                    products={results?.products ?? []}
                  />
                )}

                {results?.categories.map((category) => (
                  <div
                    key={category.id}
                    className="flex cursor-pointer items-center gap-x-2 py-3"
                  >
                    <BiCategoryAlt className="h-6 w-6 text-neutral-500" />
                    <p>همه ی کالا های</p>
                    <p>{category.name}</p>
                  </div>
                ))}
                {results?.categories.length === 0 &&
                  results.products.length === 0 && (
                    <div className="flex w-full items-center justify-center p-6">
                      هیچ موردی برای جستجوی شما یافت نشد
                    </div>
                  )}
              </>
            )}
          </CommandList>
        )}
        {input.length > 0 && (
          <div
            onClick={() => setInput("")}
            className="absolute left-5 top-1/2 flex -translate-y-1/2 cursor-pointer items-center justify-center rounded-full bg-primary p-1"
          >
            <X className="text-white" size={10} />
          </div>
        )}
      </Command>
    </>
  )
}

export default SearchBar
