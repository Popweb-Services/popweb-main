"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LucideWallet } from "lucide-react"
import { RiShoppingCartLine } from "react-icons/ri"
import { TbTruck } from "react-icons/tb"

import { cn } from "@/lib/utils"

interface OrderStepsProps {}

const OrderSteps: React.FC<OrderStepsProps> = ({}) => {
  const pathname = usePathname()
  return (
    <>
      <div className="flex items-center justify-center  gap-x-6">
        <Link href={"/checkout/cart"}>
          <div className="flex max-md:flex-col items-center gap-x-2 text-primaryColor opacity-50">
            <RiShoppingCartLine className="-scale-x-100 w-5 h-5" />
            <p className="text-center">سبد خرید</p>
          </div>
        </Link>
        <span className="w-[100px] max-md:w-[50px] max-sm:w-[20px] h-[1px] bg-primaryColor " />
        <Link href={"/checkout/shipping"}>
          <div className="flex max-md:flex-col justify-center items-center gap-x-2 text-primaryColor ">
            <TbTruck
              className={cn(
                "-scale-x-100",
                pathname === "/checkout/shipping"
                  ? "w-10 h-10 max-md:w-8 max-md:h-8"
                  : "w-5 h-5 opacity-50"
              )}
            />
            <p
              className={cn(
                "text-center",
                pathname === "/checkout/shipping"
                  ? "text-xl font-bold max-md:text-lg"
                  : "opacity-50"
              )}
            >
              نحوه ارسال
            </p>
          </div>
        </Link>

        <span
          className={cn(
            "w-[100px] max-md:w-[50px] max-sm:w-[20px] h-[1px] opacity-50",
            pathname === "checkout/payment"
              ? "bg-primaryColor"
              : "bg-neutral-500"
          )}
        />
        <div className="flex max-md:flex-col items-center gap-x-2 text-primaryColor ">
          <LucideWallet
            className={cn(
              pathname === "/checkout/payment"
                ? "w-10 h-10 text-primaryColor max-md:w-8 max-md:h-8"
                : "w-5 h-5 opacity-50 text-neutral-500"
            )}
          />
          <p
            className={cn(
              "text-center",
              pathname === "/checkout/payment"
                ? "text-xl font-bold text-primaryColor"
                : "opacity-50 text-neutral-500"
            )}
          >
            پرداخت
          </p>
        </div>
      </div>
    </>
  )
}

export default OrderSteps
