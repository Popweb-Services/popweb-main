"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import * as Dialog from "@radix-ui/react-dialog"
import { ArrowLeft } from "lucide-react"
import { BiCategory } from "react-icons/bi"

import { Category } from "@/types/products"
import { cn } from "@/lib/utils"
import useCategoryDialog from "@/hooks/use-category-dialog"

import CategoryTabs from "./category-tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { ScrollArea } from "./ui/scroll-area"

interface CategoriesNavigationMenuProps {
  categories: Category[]
}

const CategoriesNavigationMenu: React.FC<CategoriesNavigationMenuProps> = ({
  categories,
}) => {
  const [scrollY, setScrollY] = useState(window.scrollY)
  const [isMounted, setIsMounted] = useState(false)
  const { isOpen, onClose, onOpen } = useCategoryDialog()
  const [dropDownActive, setDropdownActive] = useState(false)
  useEffect(() => {
    setIsMounted(true)
  }, [])

  return (
    <div className="dropdown relative group">
      <div className="dropdown-btn cursor-pointer relative">
        <p className="pb-2">دسته بندی کالا ها</p>
        <div className="dropdown-btn-span group-hover:scale-x-100 transition-transform duration-300 origin-left w-full h-[2px] scale-x-0 bg-primaryColor bottom-0" />
      </div>
      <div className="dropdown-content hidden opacity-0 transition-opacity  duration-300 p-4 absolute border shadow-2xl rounded-b-xl bg-white min-w-[1000px] min-h-[400px] ">
        <CategoryTabs categories={categories} />
      </div>
    </div>
  )
}

export default CategoriesNavigationMenu
