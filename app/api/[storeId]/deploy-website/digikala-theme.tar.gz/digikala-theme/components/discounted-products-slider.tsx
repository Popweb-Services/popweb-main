"use client"

import { Swiper, SwiperSlide } from "swiper/react"

import "swiper/css"
import { ArrowLeftCircle } from "lucide-react"
import { AiOutlineLeft } from "react-icons/ai"
import { HiReceiptPercent } from "react-icons/hi2"

import { Product } from "@/types/products"

import ProductCard from "./ui/product-card"

interface DiscountedProductsSliderProps {
  products: Product[]
}

const DiscountedProductsSlider: React.FC<DiscountedProductsSliderProps> = ({
  products,
}) => {
  return (
    <>
      <div
        dir="rtl"
        className="relative mx-auto  mt-4 w-full overflow-hidden rounded-lg bg-primaryColor px-[3px] py-4 max-xl:rounded-none "
      >
        <Swiper
          allowTouchMove={true}
          observeParents={true}
          observeSlideChildren={true}
          observer={true}
          freeMode={true}
          slidesOffsetAfter={0}
          slidesOffsetBefore={0}
          resizeObserver={true}
          slidesPerView="auto"
          spaceBetween={3}
          direction="horizontal"
          width={undefined}
          height={undefined}
        >
          <SwiperSlide style={{ height: "auto", width: "auto" }}>
            <div className="flex h-full w-[180px] flex-col items-center justify-center space-y-4">
              <div className="text-center text-xl font-bold text-white">
                <p>تخفیف</p>
                <p>ویژه</p>
              </div>
              <HiReceiptPercent className="h-10 w-10 text-white" />
              <div className="flex items-center gap-x-2 text-white">
                <p>مشاهده همه</p>
                <AiOutlineLeft className="h-6 w-6" />
              </div>
            </div>
          </SwiperSlide>
          {products.map((product) => (
            <SwiperSlide key={product.id} style={{ height: "auto", width: "auto" }}>
              <div className="h-auto w-[180px]">
                <ProductCard product={product} />
              </div>
            </SwiperSlide>
          ))}
          <SwiperSlide style={{ height: "auto", width: "auto" }}>
            <div className="flex h-full w-[180px] cursor-pointer flex-col items-center justify-center space-y-2 rounded-xl bg-white">
              <ArrowLeftCircle className="h-11 w-11 text-primaryColor" />
              <p>مشاهده همه</p>
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </>
  )
}

export default DiscountedProductsSlider
