import { CartItem, Variant } from "@/types/products"
import Image from "next/image"
import QuantityButton from "./quantity-button"
import { priceFormatter } from "@/lib/formatter"
import { Separator } from "./separator"
import { getProductById } from "@/actions/get-product"
import { getVariantById } from "@/actions/get-variant"

interface CartItemProps {
    cartItem:CartItem
}
const CartItem: React.FC<CartItemProps> =  ({cartItem}) => {
  return (
    <>
      <div key={cartItem.product.id}>
        <div className="flex flex-col gap-y-2 p-4">
          <div className="flex gap-x-3">
            <div className="flex flex-col gap-y-2">
              <div className="relative h-[100px] w-[100px]">
                <Image
                title={cartItem.product.name}
                  src={cartItem.product.mainImageUrl}
                  alt="product image"
                  className="h-full w-full object-cover"
                  width={100} height={100}
                />
              </div>
              {cartItem.variant && cartItem.variant.priceAfterDiscount ?(
                <div className=" flex items-center justify-center rounded-full bg-white text-primaryColor">
                  تخفیف
                </div>
              ) : (
                <></>
              )}
              {!cartItem.variant && cartItem.product.priceAfterDiscount && (
                <div className=" flex items-center justify-center rounded-full bg-white text-primaryColor">
                  تخفیف
                </div>
              )}
            </div>
            {/* product info */}
            <div className="flex flex-col justify-center gap-y-2">
              <p>{cartItem.product.name}</p>
              {cartItem.variant?.options.map((option) => {
                const productOption = cartItem.product.options?.find((item) =>
                  item.values.includes(option)
                )
                return (
                  <div key={option} className="flex items-center gap-x-2 text-sm text-neutral-500">
                    <p>{productOption?.name}</p>
                    <p>:</p>
                    <p>{option}</p>
                  </div>
                )
              })}
            </div>
          </div>
          <div className="flex gap-x-3">
          <QuantityButton cartItem={cartItem} />
            <div className="flex flex-col gap-y-2">
              {cartItem.variant && (
                <>
                  {cartItem.variant.priceAfterDiscount ?
                    cartItem.variant.priceAfterDiscount > 0 &&
                    cartItem.variant.priceAfterDiscount <
                      cartItem.variant.price && (
                      <div className="flex items-center gap-x-2 text-sm text-primaryColor">
                        <p>
                          {priceFormatter(
                            (cartItem.variant.price -
                              cartItem.variant.priceAfterDiscount) *
                              cartItem.quantity
                          )}
                        </p>
                        <p>تومان تخفیف</p>
                      </div>
                    ) : (
                      <></>
                    )}
                  <div className="flex items-center gap-x-2 text-xl font-bold">
                    <p>
                      {cartItem.variant.priceAfterDiscount &&
                      cartItem.variant.priceAfterDiscount > 0 &&
                      cartItem.variant.priceAfterDiscount <
                        cartItem.variant.price
                        ? `${priceFormatter(
                            cartItem.variant.priceAfterDiscount *
                              cartItem.quantity
                          )}`
                        : `${priceFormatter(
                            cartItem.variant.price * cartItem.quantity
                          )}`}
                    </p>
                    <p>تومان</p>
                  </div>
                  {cartItem.variant.quantity <= 3 && (
                    <p className="text-sm font-medium text-rose-500">
                      تنها {cartItem.variant.quantity} در انبار باقی مانده
                    </p>
                  )}
                </>
              )}
              {!cartItem.variant && (
                <>
                  {cartItem.product.priceAfterDiscount &&
                    cartItem.product.priceAfterDiscount > 0 &&
                    cartItem.product.priceAfterDiscount <
                      cartItem.product.price && (
                      <div className="flex items-center gap-x-2 text-sm text-primaryColor">
                        <p>
                          {priceFormatter(
                            (cartItem.product.price -
                              cartItem.product.priceAfterDiscount) *
                              cartItem.quantity
                          )}
                        </p>
                        <p>تومان تخفیف</p>
                      </div>
                    )}
                  <div className="flex items-center gap-x-2 text-xl font-bold">
                    <p>
                      {cartItem.product.priceAfterDiscount &&
                      cartItem.product.priceAfterDiscount > 0 &&
                      cartItem.product.priceAfterDiscount <
                        cartItem.product.price
                        ? `${priceFormatter(
                            cartItem.product.priceAfterDiscount *
                              cartItem.quantity
                          )}`
                        : `${priceFormatter(
                            cartItem.product.price * cartItem.quantity
                          )}`}
                    </p>
                    <p>تومان</p>
                  </div>
                  {cartItem.product.quantity <= 3 && (
                    <p className="text-sm font-medium text-rose-500">
                      تنها {cartItem.product.quantity} در انبار باقی مانده
                    </p>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
        <Separator />
      </div>
    </>
  )
}

export default CartItem
