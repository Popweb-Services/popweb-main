interface SaleBadgeProps {
  price: number
  priceAfterDiscount: number
}

const SaleBadge: React.FC<SaleBadgeProps> = ({ price, priceAfterDiscount }) => {
  return (
    <>
      <div className="flex items-center  justify-center rounded-full bg-primaryColor px-1 text-sm text-white max-md:text-xs">
        {Math.floor(((price - priceAfterDiscount) / price) * 100)}%
      </div>
    </>
  )
}

export default SaleBadge
