"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { Session } from "next-auth"
import { useForm } from "react-hook-form"
import { AiOutlineLeft, AiOutlineUser } from "react-icons/ai"
import { BsPhone } from "react-icons/bs"
import { FaRegEnvelope } from "react-icons/fa"
import { MdOutlineAddLocation } from "react-icons/md"
import { z } from "zod"

import { Address } from "@/types/address"
import { Customer } from "@/types/customer"
import { addressValidator } from "@/lib/validators/address"
import useChangeAddressModal from "@/hooks/use-change-address-modal"
import useCreateAddressModal from "@/hooks/use-create-address-modal"
import useSelectedAddress from "@/hooks/use-selected-address"
import { useToast } from "@/hooks/use-toast"

import { Button } from "../button"
import { Checkbox } from "../checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../form"
import { Input } from "../input"
import { RadioGroup, RadioGroupItem } from "../radio-group"
import { ScrollArea } from "../scroll-area"
import { Separator } from "../separator"
import { Textarea } from "../textarea"
import CreateAddressModal from "./create-address-modal"

interface ChangeAddressModalProps {
  customer: Customer
}

const ChangeAddressModal: React.FC<ChangeAddressModalProps> = ({
  customer,
}) => {
  const [isReciever, setIsReciever] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const { isOpen, onClose, addresses } = useChangeAddressModal()

  const {
    onOpen: onCreateAddressModalOpen,
    onClose: onCreateAddressModalClose,
  } = useCreateAddressModal()
  const router = useRouter()
  const { setAddress } = useSelectedAddress()
  const form = useForm({
    resolver: zodResolver(addressValidator),
    defaultValues: {
      address: "",
      province: "",
      city: "",
      postCode: "",
      recieverName: "",
      recieverPhoneNumber: "",
    },
  })
  const onOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }
  useEffect(() => {
    if (isReciever) {
      form.setValue("recieverName", customer.name)
      form.setValue("recieverPhoneNumber", customer.phone)
    } else {
      form.setValue("recieverName", "")
      form.setValue("recieverPhoneNumber", "")
    }
  }, [isReciever, form, customer.name, customer.phone])

  useEffect(() => {
    setIsMounted(true)
  }, [])
  if (!isMounted) {
    return null
  }
  if (addresses.length === 0) {
    return null
  }
  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent dir="rtl" className="pb-0">
          <DialogHeader>
            <DialogTitle className="ml-auto mt-6  font-semibold">
              انتخاب آدرس
            </DialogTitle>
          </DialogHeader>
          <Separator />
          <div
            onClick={() => {
              onClose()
              onCreateAddressModalOpen()
            }}
            className="py-4 flex items-center justify-between cursor-pointer"
          >
            <div className="flex items-center gap-x-3">
              <MdOutlineAddLocation className="w-6 h-6" />
              <p>افزودن آدرس جدید</p>
            </div>
            <AiOutlineLeft />
          </div>
          <Separator />
          <ScrollArea className="w-full h-[400px] pr-6">
            <RadioGroup
              dir="rtl"
              className="divide-y-2"
              defaultValue={addresses[0].id}
              onValueChange={(value) => {
                const selectedAddress = addresses.find(
                  (address) => address.id === value
                )
                setAddress(selectedAddress!)
                onClose()
              }}
            >
              {addresses.map((address) => (
                <div key={address.id} className="flex flex-col gap-y-1 py-3">
                  <div className="flex items-center gap-x-3">
                    <RadioGroupItem value={address.id} />
                    <p>{address.address}</p>
                  </div>
                  <div className="flex flex-col gap-y-2 mr-6 pt-4 text-neutral-500">
                    <div className="flex items-center gap-x-2">
                      <FaRegEnvelope />
                      <p>{address.postCode}</p>
                    </div>
                    <div className="flex items-center gap-x-2">
                      <BsPhone />
                      <p>{address.recieverPhoneNumber}</p>
                    </div>
                    <div className="flex items-center gap-x-2">
                      <AiOutlineUser />
                      <p>{address.recieverName}</p>
                    </div>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default ChangeAddressModal
