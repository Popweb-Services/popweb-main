"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { Minus, Plus, Trash2 } from "lucide-react"
import { ImSpinner8 } from "react-icons/im"

import { CartItem } from "@/types/products"
import { useToast } from "@/hooks/use-toast"

interface QuantityButtonProps {
  cartItem: CartItem
}

const QuantityButton: React.FC<QuantityButtonProps> = ({ cartItem }) => {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const variant = cartItem.product.variants.find(
    (variant) => variant.id === cartItem.variant?.id
  )
  let maxQuantity
  if (variant) {
    maxQuantity = variant.quantity
  } else {
    maxQuantity = cartItem.product.quantity
  }
  const { toast } = useToast()
  const { mutate: incrementQuantity, isLoading: isIncrementingQuantity } =
    useMutation({
      mutationFn: async () => {
        await axios.patch(`/api/cart/decrement`, { cartItemId: cartItem.id })
      },
      onError: () => {
        toast({
          description: "خطایی پیش آمد لطفا دوباره تلاش کنید",
          variant: "destructive",
        })
      },
      onSuccess: () => {
        startTransition(() => {
          router.refresh()
        })
      },
    })
  const { mutate: decrementQuantity, isLoading: isDecrementingQuantity } =
    useMutation({
      mutationFn: async () => {
        await axios.patch(
          `${process.env.NEXT_PUBLIC_API_URL}/cart/decrement/${cartItem.id}`
        )
      },
      onError: () => {
        toast({
          description: "خطایی پیش آمد لطفا دوباره تلاش کنید",
          variant: "destructive",
        })
      },
      onSuccess: () => {
        startTransition(() => {
          router.refresh()
        })
      },
    })
  return (
    <>
      <div className="flex h-[60px] w-[100px] items-center justify-center gap-x-3 rounded-lg border bg-white p-2 shadow-md">
        <button
          className="disabled:cursor-not-allowed disabled:opacity-50"
          disabled={
            cartItem.quantity >= maxQuantity ||
            isIncrementingQuantity ||
            isPending
          }
          onClick={() => {
            incrementQuantity()
          }}
        >
          <Plus className="h-4 w-4" />
        </button>
        <div className="flex flex-col items-center justify-center">
          {isIncrementingQuantity || isDecrementingQuantity || isPending ? (
            <ImSpinner8 className="animate-spin text-primaryColor" />
          ) : (
            <>
              <p className="text-lg font-bold">{cartItem.quantity}</p>

              {cartItem.quantity === maxQuantity && (
                <p className="text-xs">حداکثر</p>
              )}
            </>
          )}
        </div>
        {cartItem.quantity > 1 ? (
          <button
            disabled={isDecrementingQuantity || isPending}
            onClick={() => decrementQuantity()}
          >
            <Minus className="h-4 w-4" />
          </button>
        ) : (
          <button
            onClick={() => {
              decrementQuantity()
            }}
          >
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>
    </>
  )
}

export default QuantityButton
