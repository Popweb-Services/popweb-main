"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { Session } from "next-auth"
import { useForm } from "react-hook-form"
import { z } from "zod"

import { Address } from "@/types/address"
import { Customer } from "@/types/customer"
import { addressValidator } from "@/lib/validators/address"
import useCreateAddressModal from "@/hooks/use-create-address-modal"
import { useToast } from "@/hooks/use-toast"

import { Button } from "../button"
import { Checkbox } from "../checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../dialog"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "../form"
import { Input } from "../input"
import { Separator } from "../separator"
import { Textarea } from "../textarea"

interface CreateAddressModalProps {
  customer: Customer
}

const CreateAddressModal: React.FC<CreateAddressModalProps> = ({
  customer,
}) => {
  const [isReciever, setIsReciever] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const router = useRouter()
  const form = useForm({
    resolver: zodResolver(addressValidator),
    defaultValues: {
      address: "",
      province: "",
      city: "",
      postCode: "",
      recieverName: "",
      recieverPhoneNumber: "",
    },
  })
  const { toast } = useToast()
  const { isOpen, onClose, onOpen, setAddress, address } =
    useCreateAddressModal()
  const { mutate: addOrUpdateAddress, isLoading: isAddingOrUpdatingAddress } =
    useMutation({
      mutationFn: async (payload: z.infer<typeof addressValidator>) => {
        if (address) {
          // update the existing address
        } else {
          await axios.post(
            `${process.env.NEXT_PUBLIC_API_URL}/customers/addresses/${customer.id}`,
            payload
          )
        }
      },
      onError: () => {
        toast({
          description: "خطایی پیش آمد لطفا بعدا تلاش کنید",
          variant: "destructive",
        })
      },
      onSuccess: () => {
        router.refresh()
      },
    })
  const onOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }
  useEffect(() => {
    if (isReciever) {
      form.setValue("recieverName", customer.name)
      form.setValue("recieverPhoneNumber", customer.phone)
    } else {
      form.setValue("recieverName", "")
      form.setValue("recieverPhoneNumber", "")
    }
  }, [isReciever, form, customer.name, customer.phone])
  useEffect(() => {
    setIsMounted(true)
  }, [])
  if (!isMounted) {
    return null
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="ml-auto mt-6  font-semibold">
              جزییات آدرس
            </DialogTitle>
          </DialogHeader>
          <Separator />

          <Form {...form}>
            <form
              className="space-y-4"
              onSubmit={form.handleSubmit((values) => {
                addOrUpdateAddress(values)
              })}
            >
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center gap-x-2">
                      <FormLabel>نشانی پستی</FormLabel>
                      <p className="text-rose-500">*</p>
                    </div>
                    <FormControl>
                      <Textarea {...field} className="h-[80px] resize-none" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="postCode"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center gap-x-2">
                      <FormLabel>کد پستی</FormLabel>
                      <p className="text-rose-500">*</p>
                    </div>
                    <FormDescription>
                      کد پستی باید 10 رقم و بدون خط تیره باشد
                    </FormDescription>
                    <FormControl>
                      <Input {...field} type="text" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-x-2">
                <FormField
                  control={form.control}
                  name="province"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center gap-x-2">
                        <FormLabel>استان</FormLabel>
                        <p className="text-rose-500">*</p>
                      </div>
                      <FormControl>
                        <Input {...field} type="text" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center gap-x-2">
                        <FormLabel>شهر</FormLabel>
                        <p className="text-rose-500">*</p>
                      </div>
                      <FormControl>
                        <Input {...field} type="text" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Separator />
              <div className="flex items-center gap-x-2">
                <Checkbox
                  onCheckedChange={() => {
                    setIsReciever((prev) => !prev)
                  }}
                />
                <p>گیرنده سفارش خودم هستم</p>
              </div>
              <FormField
                control={form.control}
                name="recieverName"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center gap-x-2">
                      <FormLabel>نام و نام خانوادگی گیرنده</FormLabel>
                      <p className="text-rose-500">*</p>
                    </div>
                    <FormControl>
                      <Input
                        {...field}
                        onChange={field.onChange}
                        disabled={isReciever}
                        type="text"
                      />
                    </FormControl>

                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="recieverPhoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <div className="flex items-center gap-x-2">
                      <FormLabel>شماره موبایل گیرنده</FormLabel>
                      <p className="text-rose-500">*</p>
                    </div>
                    <FormControl>
                      <Input
                        {...field}
                        disabled={isReciever}
                        onChange={field.onChange}
                        type="text"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button className="w-full bg-primaryColor hover:bg-primaryColor/90">
                ثبت آدرس
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default CreateAddressModal
