"use client"

import dynamic from "next/dynamic"
import Image from "next/image"

interface EditorOutputProps {
  content: any
}

const Output = dynamic(
  async () => (await import("editorjs-react-renderer")).default,
  { ssr: false }
)

const style = {
  paragraph: {
    fontSize: "1rem",
    lineHeight: "1.25rem",
  },
}

const renderers = {
  image: CustomImageRenderer,
  code: CustomCodeRenderer,
}

const EditorOutput: React.FC<EditorOutputProps> = ({ content }) => {
  return (
    <Output
      style={style}
      data={content}
      className="text-sm"
      renderers={renderers}
    />
  )
}

function CustomImageRenderer({ data }: any) {
  const src = data.file.url
  return (
    <div className="relative min-h-[15rem] w-full">
      <Image alt="image" className="object-contain" fill src={src} />
    </div>
  )
}

function CustomCodeRenderer({ data }: any) {
  return (
    <pre className="rounded-md bg-gray-800 p-4">
      <code className="text-sm text-gray-100">{data.code}</code>
    </pre>
  )
}

export default EditorOutput
