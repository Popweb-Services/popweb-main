"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"

import { Product, Variant } from "@/types/products"
import { priceFormatter } from "@/lib/formatter"

import SaleBadge from "./sale-badge"
import { Skeleton } from "./skeleton"

interface ProductCardProps {
  product: Product
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [isImageLoaded, setIsImageLoaded] = useState(false)
  let availableVariants: Variant[] = []
  if (product.variants && product.variants.length > 0) {
    availableVariants = product.variants.filter(
      (variant) => variant.quantity > 0
    )
  }
  return (
    <>
      <div
        dir="rtl"
        className="relative z-0 hover:z-20 h-full w-full cursor-pointer border-[1px] border-neutral-100 bg-white p-3 transition-all duration-300 hover:shadow-md hover:drop-shadow-lg"
      >
        <Link href={`/products/${product.id}`}>
          {product.priceAfterDiscount &&
            product.quantity !== 0 &&
            product.variants?.filter((variant) => variant.quantity !== 0)
              .length !== 0 && (
              <p className="absolute right-5 top-5 z-10 origin-top-right rounded-full border bg-white px-2 text-lg font-bold text-primaryColor shadow-sm max-md:scale-75">
                تخفیف
              </p>
            )}
          <div className=" relative aspect-square ">
            {isImageLoaded ? (
              <Image
                width={150}
                height={150}
                priority
                onLoadingComplete={() => setIsImageLoaded(true)}
                title={product.name}
                alt={product.name}
                src={product.mainImageUrl}
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                className="h-full w-full rounded-lg object-cover"
              />
            ) : (
              <Skeleton className="w-full h-full" />
            )}
          </div>
          <p className="mt-2 line-clamp-2 h-[40px] text-sm max-md:text-sm">
            {product.name}
          </p>
          {product.quantity === 0 &&
          product.variants?.filter((variant) => variant.quantity !== 0)
            .length === 0 ? (
            <div className="flex items-center justify-end text-neutral-500">
              ناموجود
            </div>
          ) : (
            <>
              {/* price section */}
              {/* variant case */}
              {availableVariants && availableVariants.length > 0 && (
                <>
                  {availableVariants[0].priceAfterDiscount ? (
                    availableVariants[0].priceAfterDiscount > 0 &&
                    availableVariants[0].priceAfterDiscount <
                      availableVariants[0].price && (
                      <div className="flex flex-col">
                        <div className="flex items-center justify-between">
                          <SaleBadge
                            price={availableVariants[0].price}
                            priceAfterDiscount={
                              availableVariants[0].priceAfterDiscount
                            }
                          />
                          <div className="flex items-center gap-x-2">
                            <p className="text-lg font-bold">
                              {priceFormatter(
                                availableVariants[0].priceAfterDiscount
                              )}
                            </p>
                            <p className="text-xs">تومان</p>
                          </div>
                        </div>
                        <div className="ml-8 flex items-center justify-end">
                          <p className="text-sm font-medium text-neutral-500 line-through">
                            {priceFormatter(availableVariants[0].price)}
                          </p>
                        </div>
                      </div>
                    )
                  ) : (
                    <div className="flex items-center justify-end">
                      <div className="flex items-center gap-x-2">
                        <p className="text-lg font-bold">
                          {priceFormatter(availableVariants[0].price)}
                        </p>
                        <p className="text-sm">تومان</p>
                      </div>
                    </div>
                  )}
                </>
              )}
              {product.variants.length > 0 &&
                availableVariants.length === 0 && (
                  <div className="flex items-center justify-end">
                    <p className="text-neutral-500">ناموجود</p>
                  </div>
                )}
            </>
          )}
          {/* product case */}
          {product.variants.length === 0 && product.quantity > 0 && (
            <div className="flex flex-col">
              {product.priceAfterDiscount &&
              product.priceAfterDiscount > 0 &&
              product.priceAfterDiscount < product.price ? (
                <>
                  <div className="flex items-center justify-between">
                    <SaleBadge
                      price={product.price}
                      priceAfterDiscount={product.priceAfterDiscount}
                    />
                    <div className="flex items-center gap-x-2">
                      <p className="text-lg font-bold">
                        {priceFormatter(product.priceAfterDiscount)}
                      </p>
                      <p className="text-sm">تومان</p>
                    </div>
                  </div>
                  <div className="ml-8 flex items-center justify-end text-sm font-medium text-neutral-500 line-through">
                    <p>{product.price}</p>
                  </div>
                </>
              ) : (
                <div className="mr-auto flex items-center gap-x-2">
                  <p className="text-lg font-bold">
                    {priceFormatter(product.price)}
                  </p>
                  <p className="text-sm">تومان</p>
                </div>
              )}
            </div>
          )}
        </Link>
      </div>
    </>
  )
}

export default ProductCard
