import { Separator } from "./separator"
import { Skeleton } from "./skeleton"

interface CartItemLoadingProps {}

const CartItemLoading: React.FC<CartItemLoadingProps> = ({}) => {
  return (
    <>
      <div>
        <div className="flex flex-col gap-y-2 p-4">
          <div className="flex gap-x-3">
            <div className="flex flex-col gap-y-2">
              <Skeleton className="relative h-[100px] w-[100px]" />
            </div>
            {/* product info */}
            <div className="flex flex-col justify-center gap-y-2">
              <Skeleton className="w-[120px] h-4" />

              <Skeleton className="w-[90px] h-4" />
            </div>
          </div>
          <div className="flex gap-x-3">
            <Skeleton className="w-[100px] h-[40px]" />
            <div className="flex flex-col gap-y-2">
              {/* {cartItem.variant && (
                <>
                  {cartItem.variant.priceAfterDiscount ? (
                    cartItem.variant.priceAfterDiscount > 0 &&
                    cartItem.variant.priceAfterDiscount <
                      cartItem.variant.price && (
                      <div className="flex items-center gap-x-2 text-sm text-primaryColor">
                        <p>
                          {priceFormatter(
                            (cartItem.variant.price -
                              cartItem.variant.priceAfterDiscount) *
                              cartItem.quantity
                          )}
                        </p>
                        <p>تومان تخفیف</p>
                      </div>
                    )
                  ) : (
                    <></>
                  )}
                  <div className="flex items-center gap-x-2 text-xl font-bold">
                    <p>
                      {cartItem.variant.priceAfterDiscount &&
                      cartItem.variant.priceAfterDiscount > 0 &&
                      cartItem.variant.priceAfterDiscount <
                        cartItem.variant.price
                        ? `${priceFormatter(
                            cartItem.variant.priceAfterDiscount *
                              cartItem.quantity
                          )}`
                        : `${priceFormatter(
                            cartItem.variant.price * cartItem.quantity
                          )}`}
                    </p>
                    <p>تومان</p>
                  </div>
                  {cartItem.variant.quantity <= 3 && (
                    <p className="text-sm font-medium text-rose-500">
                      تنها {cartItem.variant.quantity} در انبار باقی مانده
                    </p>
                  )}
                </>
              )}
              {!cartItem.variant && (
                <>
                  {cartItem.product.priceAfterDiscount &&
                    cartItem.product.priceAfterDiscount > 0 &&
                    cartItem.product.priceAfterDiscount <
                      cartItem.product.price && (
                      <div className="flex items-center gap-x-2 text-sm text-primaryColor">
                        <p>
                          {priceFormatter(
                            (cartItem.product.price -
                              cartItem.product.priceAfterDiscount) *
                              cartItem.quantity
                          )}
                        </p>
                        <p>تومان تخفیف</p>
                      </div>
                    )}
                  <div className="flex items-center gap-x-2 text-xl font-bold">
                    <p>
                      {cartItem.product.priceAfterDiscount &&
                      cartItem.product.priceAfterDiscount > 0 &&
                      cartItem.product.priceAfterDiscount <
                        cartItem.product.price
                        ? `${priceFormatter(
                            cartItem.product.priceAfterDiscount *
                              cartItem.quantity
                          )}`
                        : `${priceFormatter(
                            cartItem.product.price * cartItem.quantity
                          )}`}
                    </p>
                    <p>تومان</p>
                  </div>
                  {cartItem.product.quantity <= 3 && (
                    <p className="text-sm font-medium text-rose-500">
                      تنها {cartItem.product.quantity} در انبار باقی مانده
                    </p>
                  )}
                </>
              )} */}
            </div>
          </div>
        </div>
        <Separator />
      </div>
    </>
  )
}

export default CartItemLoading
