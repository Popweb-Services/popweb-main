import { Skeleton } from "./skeleton"

interface ProductCardSkeletonProps {}

const ProductCardSkeleton: React.FC<ProductCardSkeletonProps> = ({}) => {
  return (
    <>
      <div className="w-full space-y-2 border p-6">
        <Skeleton className="aspect-square w-full" />
        <div className="flex items-center justify-between">
          <Skeleton className="h-[20px] w-[100px]" />
          <Skeleton className="h-[20px] w-[50px]" />
        </div>
        <Skeleton className="h-[10px] w-[80px]" />
      </div>
    </>
  )
}

export default ProductCardSkeleton
