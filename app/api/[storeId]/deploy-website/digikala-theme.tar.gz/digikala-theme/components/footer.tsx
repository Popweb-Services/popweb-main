"use client"

import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { getStore } from "@/actions/get-store"
import { Balancer } from "react-wrap-balancer"

import { Store } from "@/types/store"

import { Separator } from "./ui/separator"

interface FooterProps {
  store: Store
}

const Footer = ({ store }: FooterProps) => {
  const pathname = usePathname()
  if (pathname === "/checkout/shipping") {
    return null
  } else if (pathname === "/checkout/payment") {
    return null
  } else if (pathname === "/checkout/success") {
    return null
  }
  return (
    <>
      <footer dir="rtl" className="mt-6 w-full border-t max-md:pb-[60px]">
        <div className="container w-full py-6">
          <div className="flex items-center gap-x-2 text-neutral-500">
            <p>شماره تماس :</p>
            <p>02122968748</p>
          </div>
        </div>
        <Separator />
        <div className="container grid w-full grid-cols-3 gap-x-6 py-6">
          <div className="col-span-2 space-y-2">
            <h1 className="text-2xl font-bold">
              فروشگاه اینترنتی {store.name} ، برسی ، انتخاب و خرید آنلاین
            </h1>
            <p className="text-neutral-500">
              <Balancer>{store.description}</Balancer>
            </p>
          </div>
        </div>
        <Separator />
        <div className="flex w-full flex-col items-center justify-center space-y-2 py-6 text-sm text-neutral-500">
          <p> تمامی حقوق این وبسایت متعلق به فروشگاه {store.name} می باشد.</p>
          <p>
            طراحی توسط{" "}
            <Link href="popweb.ir" className="font-bold text-sky-400 underline">
              فروشگاه ساز پاپ وب
            </Link>
            .
          </p>
        </div>
      </footer>
    </>
  )
}

export default Footer
