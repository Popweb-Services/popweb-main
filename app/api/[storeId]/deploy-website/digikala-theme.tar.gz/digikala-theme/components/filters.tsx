"use client"

import { useState, useTransition } from "react"
import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { Slider } from "@mui/material"
import Box from "@mui/material/Box"
import { ImSpinner8 } from "react-icons/im"

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion"
import { Separator } from "./ui/separator"
import { Switch } from "./ui/switch"

interface FiltersProps {
  categoryId: string
}

const Filters: React.FC<FiltersProps> = ({ categoryId }) => {
  const searchParams = useSearchParams()
  const pathname = usePathname()
  const router = useRouter()
  const params = new URLSearchParams(searchParams)
  const [isPending, startTransition] = useTransition()
  const [priceRangeValue, setPriceRangeValue] = useState([0, 100])
  const handlePriceRangeChange = (
    event: Event,
    newValue: number | number[]
  ) => {
    setPriceRangeValue(newValue as number[])
  }
  return (
    <>
      {isPending && (
        <div className="fixed inset-0 z-50 bg-white opacity-50 flex items-center justify-center">
          <ImSpinner8 className="w-10 h-10 text-primaryColor animate-spin" />
        </div>
      )}
      <div className="pt-2 relative">
        <div className="rounded-lg sticky top-[20px] border max-lg:hidden">
          <div className="flex p-4 items-center justify-between">
            <p className="font-semibold">فیلتر ها</p>
            <div
              onClick={() => {
                startTransition(() => {
                  router.push(`/products?category=${categoryId}`)
                })
              }}
              className="text-primaryColor cursor-pointer"
            >
              حذف فیلتر ها
            </div>
          </div>
          <div className="">
            <Accordion type="multiple">
              <AccordionItem className="p-4 border-none" value="price-range">
                <AccordionTrigger className="no-underline p-0 hover:no-underline">
                  محدوده قیمت
                </AccordionTrigger>
                <AccordionContent className="flex items-center flex-col justify-center">
                  <Box sx={{ width: 200 }}>
                    <Slider
                      sx={{
                        "& .MuiSlider-thumb": {
                          width: "20px",
                          height: "20px",
                        },
                      }}
                      onChange={handlePriceRangeChange}
                      value={priceRangeValue}
                      className="mt-4"
                    />
                  </Box>
                  <p className="text-center text-sm text-neutral-500">(بازه قیمتی به تومان می باشد)</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          <Separator />
          <div className="flex p-4 items-center justify-between">
            <p>فقط کالا های موجود</p>
            <Switch
              dir="ltr"
              onCheckedChange={() => {
                if (searchParams.get("available") === "true") {
                  params.delete("available")
                } else {
                  params.set("available", "true")
                }
                startTransition(() => {
                  router.push(`${pathname}?${params}`)
                })
              }}
              defaultChecked={searchParams.get("available") === "true"}
            />
          </div>
          <Separator />
          <div className="flex p-4 items-center justify-between">
            <p>تخفیف</p>
            <Switch
              dir="ltr"
              defaultChecked={searchParams.get("discounted") === "true"}
              onCheckedChange={() => {
                if (searchParams.get("discounted") === "true") {
                  params.delete("discounted")
                } else {
                  params.set("discounted", "true")
                }
                startTransition(() => {
                  router.push(`${pathname}?${params}`)
                })
              }}
            />
          </div>
        </div>
      </div>
    </>
  )
}

export default Filters
