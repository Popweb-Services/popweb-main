"use client"

import { useEffect, useState, useTransition } from "react"
import { revalidatePath } from "next/cache"
import { Fascinate_Inline } from "next/font/google"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"
import { CircleDot, X } from "lucide-react"
import { Session } from "next-auth"
import { useCookies } from "react-cookie"
import { useFieldArray, useForm } from "react-hook-form"
import { ImSpinner8 } from "react-icons/im"

import { CartItem, Product, Variant } from "@/types/products"
import { priceFormatter } from "@/lib/formatter"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

import { Button } from "./ui/button"
import { Label } from "./ui/label"
import QuantityButton from "./ui/quantity-button"
import { RadioGroup, RadioGroupItem } from "./ui/radio-group"
import SaleBadge from "./ui/sale-badge"
import { Separator } from "./ui/separator"

interface ProductAddToCartProps {
  cartItems: CartItem[]
  product: Product
  session: Session | null
}

const ProductAddToCart: React.FC<ProductAddToCartProps> = ({
  cartItems,
  product,
  session,
}) => {
  const [isMounted, setIsMounted] = useState(false)
  const availableVariants = product.variants?.filter(
    (variant) => variant.quantity !== 0
  )
  let availableOptions: string[] = []
  if (availableVariants) {
    availableVariants.map((variant) => {
      variant.options.map((value) => availableOptions.push(value))
    })
  }

  const form = useForm({
    defaultValues: {
      options: product.options?.map((option) => ({
        name: option.name,
        value: option.values.find((value) => availableOptions.includes(value)),
      })),
    },
  })
  const { toast } = useToast()
  const pathname = usePathname()
  const formOptions = form.watch("options")
  const [isVariantInBasket, setIsVariantInBasket] = useState<boolean>()
  const [isProductInBasket, setIsProductInBasket] = useState<boolean>()
  const [productCartItem, setProductCartItem] = useState<CartItem | undefined>()
  const [variantCartItem, setVariantCartItem] = useState<CartItem | undefined>()
  const [selectedVariant, setSelectedVariant] = useState<Variant>()
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const [cookies, setCookie] = useCookies(["device_id"])

  const { mutate: addToCart, isLoading: isAddingToCart } = useMutation({
    mutationFn: async () => {
      await axios.post(`/api/cart/add-to-cart`, {
        customerId: session?.user.id,
        productId: product.id,
        variantId: selectedVariant?.id,
        deviceId: cookies.device_id,
      })
    },
    onSuccess: () => {
      startTransition(() => {
        router.refresh()
      })
    },
  })
  useEffect(() => {
    const selectedOptions = formOptions?.map((option) => option.value)

    const productInBasket = cartItems.find(
      (item) => item.product.id === product.id
    )
    if (productInBasket) {
      setIsProductInBasket(true)
      setProductCartItem(productInBasket)
    } else {
      setIsProductInBasket(false)
    }

    setSelectedVariant(
      availableVariants?.find(
        (variant) => variant.options.toString() === selectedOptions?.toString()
      )
    )
  }, [formOptions, cartItems, availableVariants, product.id])
  useEffect(() => {
    setIsMounted(true)
  }, [])
  useEffect(() => {
    const vraiantInBasket = cartItems.find(
      (item) => item.variant?.id === selectedVariant?.id
    )
    if (vraiantInBasket) {
      setIsVariantInBasket(true)
      setVariantCartItem(vraiantInBasket)
    } else {
      setIsVariantInBasket(false)
    }
  }, [cartItems, selectedVariant])
  if (!isMounted) {
    return null
  }
  return (
    <>
      <div className="mt-6 w-full ">
        <div className="col-span-2">
          {product.options?.length !== 0 && (
            <div className="">
              {product.options?.map((option, index) => {
                let availableVariants: Variant[] | undefined
                option.values.map((value) => {
                  availableVariants = product.variants?.filter(
                    (variant) => variant.quantity !== 0
                  )
                })
                const availableOptions: string[] = []
                availableVariants?.map((variant) =>
                  variant.options.map((value) => availableOptions.push(value))
                )
                const defaultRadioValues = option.values.filter((value) =>
                  availableOptions.includes(value)
                )
                return (
                  <>
                    <div className="text-xl font-bold">{option.name}</div>
                    <RadioGroup
                      onValueChange={(radioValue: string) => {
                        let newOptionList = formOptions
                        newOptionList![index].value = radioValue
                        form.setValue("options", newOptionList)
                      }}
                      defaultValue={defaultRadioValues[0]}
                      dir="rtl"
                      className="items-center space-y-2 py-4"
                    >
                      {option.values.map((value) => {
                        const filteredVariants = product.variants?.filter(
                          (variant) =>
                            variant.options.includes(value) &&
                            variant.quantity !== 0
                        )
                        return (
                          <div
                            key={option.id}
                            className={cn(
                              "flex items-center gap-x-2",
                              filteredVariants?.length === 0 && "opacity-50"
                            )}
                          >
                            <RadioGroupItem
                              value={value}
                              disabled={
                                filteredVariants?.length === 0 ? true : false
                              }
                            />
                            <Label>{value}</Label>
                            {filteredVariants?.length === 0 && (
                              <div className="flex items-center gap-x-2">
                                <X />
                                <p>ناموجود</p>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </RadioGroup>
                    <Separator className="my-4" />
                  </>
                )
              })}
            </div>
          )}
          {product.features?.length! > 0 && (
            <div className="flex flex-col gap-y-2 py-2">
              <h2 className="text-lg font-bold">ویژگی ها</h2>
              <ul className="space-y-3">
                {product.features?.map((feature) => (
                  <li key={feature.id} className="flex items-center gap-x-2">
                    <div className="h-1 w-1 rounded-full bg-neutral-500"></div>
                    <p className="text-neutral-500">{feature.name}</p>
                    <p className="text-neutral-500">:</p>
                    {feature.value}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
        <div className="w-full space-y-2 rounded-xl bg-secondary p-3 max-md:hidden">
          {/* out of stock cases */}
          {product.variants?.length! > 0 && availableVariants?.length === 0 && (
            <div className="flex items-center justify-center gap-x-2 text-neutral-500">
              <span className="h-[1px] w-full rounded-full bg-neutral-500" />
              <p>ناموجود</p>
              <span className="h-[1px] w-full rounded-full bg-neutral-500" />
            </div>
          )}
          {product.variants?.length! === 0 && product.quantity === 0 && (
            <div className="flex items-center justify-center gap-x-2 text-neutral-500">
              <span className="h-[1px] w-full rounded-full bg-neutral-500" />
              <p>ناموجود</p>
              <span className="h-[1px] w-full rounded-full bg-neutral-500" />
            </div>
          )}
          {/* in stock cases */}
          {product.variants?.length! > 0 && availableVariants?.length! > 0 && (
            <div className="flex flex-col gap-y-2">
              {selectedVariant?.priceAfterDiscount! > 0 && (
                <div className="flex items-center justify-between">
                  <p>قیمت اصلی</p>
                  <div className="flex items-center gap-x-2">
                    <p className="text-neutral-500 line-through">
                      {priceFormatter(selectedVariant?.price!)}
                    </p>
                    <SaleBadge
                      price={selectedVariant?.price!}
                      priceAfterDiscount={selectedVariant?.priceAfterDiscount!}
                    />
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between">
                <p>
                  {selectedVariant?.priceAfterDiscount! > 0 &&
                  selectedVariant?.priceAfterDiscount! < selectedVariant?.price!
                    ? "قیمت بعد از تخفیف"
                    : "قیمت"}
                </p>
                <div className="flex items-center gap-x-2">
                  <p>
                    {selectedVariant?.priceAfterDiscount! > 0 &&
                    selectedVariant?.priceAfterDiscount! <
                      selectedVariant?.price!
                      ? `${priceFormatter(
                          selectedVariant?.priceAfterDiscount!
                        )}`
                      : `${priceFormatter(selectedVariant?.price!)}`}
                  </p>
                  <p>تومان</p>
                </div>
              </div>
              {selectedVariant?.quantity! <= 3 && (
                <p className="text-sm font-medium text-rose-500">
                  تنها {selectedVariant?.quantity!} عدد در انبار باقی مانده
                </p>
              )}
              {isVariantInBasket ? (
                <div className="flex items-center justify-start gap-x-3">
                  <QuantityButton cartItem={variantCartItem!} />
                  <div className="flex flex-col">
                    <p>در سبد خرید شما</p>
                    <div className="flex items-center gap-x-2 text-sm">
                      <p>مشاهده</p>
                      <Link
                        href={"/checkout/cart"}
                        className="text-primaryColor"
                      >
                        سبد خرید
                      </Link>
                    </div>
                  </div>
                </div>
              ) : (
                <Button
                  disabled={isAddingToCart || isPending}
                  onClick={() => addToCart()}
                  className="bg-primaryColor hover:bg-primaryColor/90"
                >
                  {isAddingToCart || isPending ? (
                    <ImSpinner8 className="animate-spin" />
                  ) : (
                    <p> افزودن به سبد خرید</p>
                  )}
                </Button>
              )}
            </div>
          )}
          {product.variants?.length === 0 && product.quantity > 0 && (
            <div className="flex flex-col gap-y-2">
              {product.priceAfterDiscount &&
                product.priceAfterDiscount > 0 &&
                product.priceAfterDiscount < product.price && (
                  <div className="flex items-center justify-between">
                    <p>قیمت اصلی</p>
                    <div className="flex items-center gap-x-2">
                      <p className="text-neutral-500 line-through">
                        {priceFormatter(product.price)}
                      </p>
                      <SaleBadge
                        price={product.price}
                        priceAfterDiscount={product.priceAfterDiscount}
                      />
                    </div>
                  </div>
                )}
              <div className="flex items-center justify-between">
                <p>
                  {product.priceAfterDiscount &&
                  product.priceAfterDiscount > 0 &&
                  product.priceAfterDiscount < product.price
                    ? "قیمت بعد از تخفیف"
                    : "قیمت"}
                </p>
                <div className="flex items-center gap-x-2">
                  <p>
                    {product.priceAfterDiscount &&
                    product.priceAfterDiscount > 0 &&
                    product.priceAfterDiscount < product.price
                      ? `${priceFormatter(product.priceAfterDiscount)}`
                      : `${priceFormatter(product.price)}`}
                  </p>
                  <p>تومان</p>
                </div>
              </div>
              {product.quantity <= 3 && (
                <p className="text-sm font-medium text-rose-500">
                  تنها {product.quantity} عدد در انبار باقی مانده
                </p>
              )}
              {isProductInBasket === true ? (
                <div className="flex items-center justify-start gap-x-3">
                  <QuantityButton cartItem={productCartItem!} />
                  <div className="flex flex-col">
                    <p>در سبد خرید شما</p>
                    <div className="flex items-center gap-x-2 text-sm">
                      <p>مشاهده</p>
                      <Link
                        href={"/checkout/cart"}
                        className="text-primaryColor"
                      >
                        سبد خرید
                      </Link>
                    </div>
                  </div>
                </div>
              ) : (
                <Button
                  disabled={isAddingToCart || isPending}
                  onClick={() => addToCart()}
                  className="bg-primaryColor hover:bg-primaryColor/90"
                >
                  {isAddingToCart || isPending ? (
                    <ImSpinner8 className="animate-spin" />
                  ) : (
                    <p> افزودن به سبد خرید</p>
                  )}
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="fixed inset-x-0 bottom-[50px] z-10 flex w-full flex-col gap-y-2 border-t bg-white p-4 pb-5 md:hidden">
        {/* variant case */}
        {selectedVariant && (
          <>
            {selectedVariant && selectedVariant.quantity <= 3 && (
              <p className="text-xs font-medium text-rose-500">
                تنها {selectedVariant.quantity} عدد در انبار باقی مانده
              </p>
            )}
            <div className="flex items-center justify-between">
              {isVariantInBasket ? (
                <QuantityButton cartItem={variantCartItem!} />
              ) : (
                <Button
                  disabled={isAddingToCart || isPending}
                  onClick={() => addToCart()}
                  className="bg-primaryColor hover:bg-primaryColor/90"
                >
                  {isAddingToCart || isPending ? (
                    <ImSpinner8 className="animate-spin" />
                  ) : (
                    <p> افزودن به سبد خرید</p>
                  )}
                </Button>
              )}
              <div className="flex flex-col gap-y-1">
                {selectedVariant.priceAfterDiscount &&
                selectedVariant.priceAfterDiscount > 0 &&
                selectedVariant.priceAfterDiscount !== selectedVariant.price ? (
                  <div className="flex items-center gap-x-2">
                    <p className="text-sm text-neutral-500 line-through">
                      {priceFormatter(selectedVariant.priceAfterDiscount)}
                    </p>
                    <SaleBadge
                      price={selectedVariant.price}
                      priceAfterDiscount={selectedVariant.priceAfterDiscount}
                    />
                  </div>
                ) : (
                  <></>
                )}
                <div className="flex items-center gap-x-2 text-lg font-bold">
                  <p>{priceFormatter(selectedVariant.price)}</p>
                  <p>تومان</p>
                </div>
              </div>
            </div>
          </>
        )}
        {product && !selectedVariant && (
          <>
            {product && product.quantity <= 3 && (
              <p className="text-xs font-medium text-rose-500">
                تنها {product.quantity} عدد در انبار باقی مانده
              </p>
            )}
            <div className="flex items-center justify-between">
              {isVariantInBasket ? (
                <QuantityButton cartItem={variantCartItem!} />
              ) : (
                <Button
                  disabled={isAddingToCart || isPending}
                  onClick={() => addToCart()}
                  className="bg-primaryColor hover:bg-primaryColor/90"
                >
                  {isAddingToCart || isPending ? (
                    <ImSpinner8 className="animate-spin" />
                  ) : (
                    <p> افزودن به سبد خرید</p>
                  )}
                </Button>
              )}
              <div className="flex flex-col gap-y-1">
                {product.priceAfterDiscount &&
                  product.priceAfterDiscount > 0 &&
                  product.priceAfterDiscount !== product.price && (
                    <div className="flex items-center gap-x-2">
                      <p className="text-sm text-neutral-500 line-through">
                        {priceFormatter(product.priceAfterDiscount)}
                      </p>
                      <SaleBadge
                        price={product.price}
                        priceAfterDiscount={product.priceAfterDiscount}
                      />
                    </div>
                  )}
                <div className="flex items-center gap-x-2 text-lg font-bold">
                  <p>{priceFormatter(product.price)}</p>
                  <p>تومان</p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  )
}

export default ProductAddToCart
