"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useMutation } from "@tanstack/react-query"
import axios from "axios"

import { Order } from "@/types/order"
import { CartItem } from "@/types/products"
import { ShippingRate } from "@/types/shipping-rate"
import { priceFormatter } from "@/lib/formatter"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

import { Button, buttonVariants } from "./ui/button"
import { Separator } from "./ui/separator"

interface OrderSummaryProps {
  shippingRate?: ShippingRate
  addressId?: string
  customerId: string
  customerPhone?: string
  cartItems: CartItem[]
}

const OrderSummary: React.FC<OrderSummaryProps> = ({
  customerPhone,
  customerId,
  addressId,
  cartItems,
  shippingRate,
}) => {
  const router = useRouter()
  const { toast } = useToast()
  const pathname = usePathname()
  const [cartQuantityCount, setCartQuantityCount] = useState<number>()
  const [totalPrice, setTotalPrice] = useState<number>(0)
  const [totalBasketPrice, setTotalBasketPrice] = useState<number>(0)
  const [isMounted, setIsMounted] = useState(false)
  const { mutate: redirectToPaymentGateway, isLoading } = useMutation({
    mutationFn: async (orderId: string) => {
      const { data } = await axios.post("/api/payment/get-token", {
        amount: totalBasketPrice * 10,
        mobile_number: customerPhone,
        orderId: orderId,
      })

      router.push(`https://ipg.vandar.io/v3/${data.token}`)
    },
  })
  const { mutate: placeOrder, isLoading: isPlacingOrder } = useMutation({
    mutationFn: async () => {
      const { data } = await axios.post(`/api/checkout/place-order`, {
        cartItems: cartItems,
        shippingRateId: shippingRate?.id,
        customerAddressId: addressId,
        customerId: customerId,
      })
      redirectToPaymentGateway(data.id)
    },
    onError: () => {
      toast({
        description: "خطایی پیش آمد لطفا بعدا تلاش کنید.",
        variant: "destructive",
      })
    },
  })
  useEffect(() => {
    setIsMounted(true)
  }, [])
  useEffect(() => {
    const count = cartItems.reduce((acc, item) => {
      return acc + item.quantity
    }, 0)
    setCartQuantityCount(count)
    const totalProductPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        return acc + item.variant.price * item.quantity
      } else {
        return acc + item.product.price * item.quantity
      }
    }, 0)
    setTotalPrice(totalProductPrice)
    const totalProductBasketPrice = cartItems.reduce((acc, item) => {
      if (item.variant) {
        if (item.variant.priceAfterDiscount) {
          return acc + item.variant.priceAfterDiscount * item.quantity
        } else {
          return acc + item.variant.price * item.quantity
        }
      } else {
        if (item.product.priceAfterDiscount) {
          return acc + item.product.priceAfterDiscount * item.quantity
        } else {
          return acc + item.product.price * item.quantity
        }
      }
    }, 0)
    if (shippingRate) {
      setTotalBasketPrice(totalProductBasketPrice + shippingRate.price)
    } else {
      setTotalBasketPrice(totalProductBasketPrice)
    }
  }, [cartItems, shippingRate])
  if (!isMounted) {
    return null
  }
  return (
    <>
      {cartItems.length !== 0 && (
        <div className="max-lg:hidden">
          <div className="sticky top-20 w-full space-y-2 rounded-lg border p-4 transition-shadow max-md:block  max-md:border-none">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-x-2 text-sm">
                <p>قیمت کالاها</p>
                <p>({cartQuantityCount})</p>
              </div>
              <div className="flex items-center gap-x-2">
                <p>{priceFormatter(totalPrice)}</p>
                <p>تومان</p>
              </div>
            </div>
            <Separator />
            {shippingRate && (
              <div className="flex items-center justify-between">
                <p>هزینه ارسال</p>
                <div className="flex items-center gap-x-2">
                  <p>{priceFormatter(shippingRate?.price)}</p>
                  <p>تومان</p>
                </div>
              </div>
            )}

            <Separator />
            {cartItems.filter(
              (item) =>
                (item.variant?.priceAfterDiscount &&
                  item.variant.priceAfterDiscount > 0) ||
                (item.product.priceAfterDiscount &&
                  item.product?.priceAfterDiscount > 0)
            ).length > 0 && (
              <>
                {totalPrice - totalBasketPrice > 0 && (
                  <>
                    <div className="flex items-center justify-between text-sm text-primaryColor">
                      <p>تخفیف</p>
                      <div className="flex items-center gap-x-2">
                        {Math.floor(
                          ((totalPrice - totalBasketPrice) / totalPrice) * 100
                        ) > 1 && (
                          <p>
                            (
                            {Math.floor(
                              ((totalPrice - totalBasketPrice) / totalPrice) *
                                100
                            )}
                            %)
                          </p>
                        )}

                        <p>
                          {shippingRate
                            ? priceFormatter(
                                totalPrice -
                                  totalBasketPrice +
                                  shippingRate.price
                              )
                            : priceFormatter(totalPrice - totalBasketPrice)}
                        </p>
                        <p>تومان</p>
                      </div>
                    </div>
                    <Separator />
                  </>
                )}
              </>
            )}
            <div className="flex items-center justify-between text-sm font-bold">
              <p>قابل پرداخت</p>
              <div className="flex items-center gap-x-2">
                <p>{priceFormatter(totalBasketPrice)}</p>
                <p>تومان</p>
              </div>
            </div>

            <Button
              disabled={isPlacingOrder}
              onClick={() => {
                if (pathname === "/checkout/shipping") {
                  return router.push(
                    `/checkout/payment?shippingRate=${shippingRate?.id}&addressId=${addressId}`
                  )
                }
                placeOrder()
              }}
              className="w-full bg-primaryColor hover:bg-primaryColor/90"
            >
              {pathname === "/checkout/shipping" ? (
                <p>ثبت سفارش</p>
              ) : (
                <p>پرداخت</p>
              )}
            </Button>
          </div>
        </div>
      )}
    </>
  )
}

export default OrderSummary
