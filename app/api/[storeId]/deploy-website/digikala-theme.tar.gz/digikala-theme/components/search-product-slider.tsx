"use client"

import { Swiper, SwiperSlide } from "swiper/react"

import "swiper/css"
import Image from "next/image"
import { useRouter } from "next/navigation"

import { Product } from "@/types/products"

import ProductCard from "./ui/product-card"

interface SearchProductSliderProps {
  products: Product[]
  onProductSelect: () => void
}

const SearchProductSlider: React.FC<SearchProductSliderProps> = ({
  products,
  onProductSelect,
}) => {
  const router = useRouter()
  return (
    <>
      <div
        dir="rtl"
        className="relative mx-auto  mt-4 w-full max-w-7xl overflow-hidden rounded-lg py-4 max-xl:rounded-none "
      >
        <Swiper
          allowTouchMove={true}
          observeParents={true}
          observeSlideChildren={true}
          observer={true}
          freeMode={true}
          slidesOffsetAfter={0}
          slidesOffsetBefore={0}
          resizeObserver={true}
          slidesPerView="auto"
          spaceBetween={10}
          direction="horizontal"
          width={undefined}
          height={undefined}
        >
          {products.map((product) => (
            <SwiperSlide style={{ height: "80px", width: "auto" }}>
              <div
                onClick={() => {
                  router.push(`/products/${product.id}`)
                  onProductSelect()
                }}
                className="flex h-[80px] w-[200px] cursor-pointer items-center rounded-lg border bg-white py-2"
              >
                <div className=" relative">
                  <Image
                    width={80}
                    height={80}
                    alt="product image"
                    className="object-cover"
                    src={product.mainImageUrl}
                  />
                </div>
                <div className="mr-6 flex w-full flex-col gap-y-2 truncate ">
                  {product.category && <p>{product.category.name}</p>}
                  <p className="truncate">{product.name}</p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </>
  )
}

export default SearchProductSlider
