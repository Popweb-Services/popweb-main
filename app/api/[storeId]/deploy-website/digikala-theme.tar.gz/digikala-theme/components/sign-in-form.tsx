"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useMutation } from "@tanstack/react-query"
import axios, { AxiosError } from "axios"
import { ArrowLeft, ArrowRight } from "lucide-react"
import { getSession, signIn } from "next-auth/react"
import { useCookies } from "react-cookie"
import { useForm } from "react-hook-form"
import { z } from "zod"

import {
  phoneNumberValidator,
  verifyCodeValidator,
} from "@/lib/validators/auth"

import { useToast } from "../hooks/use-toast"
import { Button } from "./ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./ui/form"
import { Input } from "./ui/input"

interface SignInFormProps {}

enum LoginSteps {
  PHONE = 0,
  VERIFY = 1,
  NAME = 2,
}

const SignInForm: React.FC<SignInFormProps> = ({}) => {
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [cookies, setCookie, removeCookie] = useCookies(["device_id"])
  const router = useRouter()
  const [step, setStep] = useState(LoginSteps.PHONE)
  const [isNewUser, setIsNewUser] = useState(true)
  const timerId = useRef<any>()
  const [counter, setCounter] = useState(0)
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const { mutate: sendOTP, isLoading } = useMutation({
    mutationFn: async (payload: z.infer<typeof phoneNumberValidator>) => {
      const { data } = await axios.post(`/api/auth/send-code`, payload)
      setIsNewUser(data.isNewUser)
      setStep(LoginSteps.VERIFY)
      setCounter(120)
    },
  })
  const phoneForm = useForm({
    resolver: zodResolver(phoneNumberValidator),
    defaultValues: {
      phone: "",
    },
  })
  const phoneNumber = phoneForm.watch("phone")
  const verificationForm = useForm({
    resolver: zodResolver(verifyCodeValidator),
    defaultValues: {
      code: undefined,
    },
  })
  const code = verificationForm.watch("code")
  const nameForm = useForm({
    defaultValues: {
      name: "",
    },
  })
  const { mutate: updateUserCart, isLoading: isUpdatingUserCart } = useMutation(
    {
      mutationFn: async ({
        customerId,
        deviceId,
      }: {
        customerId: string
        deviceId: string
      }) => {
        await axios.patch(
          `${process.env.NEXT_PUBLIC_API_URL}/cart?deviceId=${deviceId}&customerId=${customerId}`
        )
      },
      onSuccess: () => {
        removeCookie("device_id")
      },
    }
  )
  const { mutate: checkOTP, isLoading: isVerifyingCode } = useMutation({
    mutationFn: async () => {
      await axios.post(`api/auth/check-code`, {
        code: code,
        phoneNumber: phoneNumber,
      })
    },
    onError: (error) => {
      if (error instanceof AxiosError) {
        if (error.response?.status === 401) {
          toast({
            description: "کد تایید نا معتبر است",
            variant: "destructive",
          })
        }
      }
    },
    onSuccess: () => {
      if (isNewUser) {
        setStep(LoginSteps.NAME)
      } else {
        signIn("credentials", {
          phone: phoneNumber,
          otp: code,
          redirect: false,
        }).then(async () => {
          const session = await getSession()
          console.log(session)
          updateUserCart({
            deviceId: cookies.device_id,
            customerId: session?.user.id!,
          })
          router.push(searchParams.get("backUrl") ?? "/")
          router.refresh()
        })
      }
    },
  })
  const { mutate: updateName, isLoading: isUpdatingName } = useMutation({
    mutationFn: async (values: { name: string }) => {
      await axios.patch(
        `${process.env.NEXT_PUBLIC_API_URL}/customers/${phoneNumber}`,
        { name: values.name }
      )
    },
    onError: () => {
      toast({
        description: "خطایی پیش آمد ، لطفا دوباره تلاش کنید",
        variant: "destructive",
      })
    },
    onSuccess: () => {
      signIn("credentials", {
        phone: phoneNumber,
        otp: code,
        redirect: false,
      }).then(async (callback) => {
        if (callback?.error) {
          toast({
            description: "خطایی پیش آمد ، لطفا دوباره تلاش کنید",
            variant: "destructive",
          })
        } else {
          const session = await getSession()
          updateUserCart({
            deviceId: cookies.device_id,
            customerId: session?.user.id!,
          })
          router.push(searchParams.get("backUrl") ?? "/")
        }
      })
    },
  })
  const convertSeconds = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds}`
  }
  useEffect(() => {
    timerId.current = setInterval(() => setCounter((prev) => prev - 1), 1000)
    return () => clearInterval(timerId.current)
  }, [counter])
  useEffect(() => {
    if (counter <= 0) {
      clearInterval(timerId.current)
    }
  }, [counter])
  return (
    <div dir="rtl" className="mt-6">
      {step === LoginSteps.PHONE && (
        <>
          <div className="mt-5 flex items-center gap-x-3">
            <p>ورود</p>
            <span className="h-[20px] w-[1px] bg-black" />
            <p>ثبت نام</p>
          </div>
          <Form {...phoneForm}>
            <form
              onSubmit={phoneForm.handleSubmit((values) => {
                sendOTP(values)
              })}
              className="mt-6 space-y-6"
            >
              <FormField
                control={phoneForm.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormDescription>
                      لطفا شماره موبایل خود را وارد کنید.
                    </FormDescription>
                    <FormControl>
                      <Input
                        autoComplete="false"
                        {...field}
                        className="h-[44px]"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                disabled={isLoading}
                type="submit"
                className="w-full bg-primaryColor hover:bg-primaryColor/90"
              >
                ادامه
              </Button>
            </form>
          </Form>
        </>
      )}
      {step === LoginSteps.VERIFY && (
        <>
          <Button
            onClick={() => {
              setStep(LoginSteps.PHONE)
              setCounter(0)
            }}
            variant="ghost"
            className="absolute right-3 top-10"
          >
            <ArrowRight />
          </Button>
          <h1 className="text-xl font-bold">کد تایید را وارد کنید.</h1>
          <Form {...verificationForm}>
            <form
              onSubmit={verificationForm.handleSubmit((values) => {
                checkOTP()
              })}
              className="mt-6 space-y-6"
            >
              <FormField
                control={verificationForm.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormDescription>
                      کد تایید برای شماره {phoneNumber} ارسال شد
                    </FormDescription>
                    <FormControl>
                      <Input
                        autoComplete="false"
                        {...field}
                        className="h-[44px]"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {counter === 0 ? (
                <div className="flex items-center justify-center">
                  <button
                    type="button"
                    onClick={() => {
                      sendOTP({ phone: phoneNumber })
                    }}
                    disabled={isVerifyingCode}
                    className="underline underline-offset-2"
                  >
                    دریافت مجدد کد
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-x-2">
                  <p>{`${Math.floor(counter / 60)}:${counter % 60}`}</p>
                  <p>مانده تا دریافت مجدد کد</p>
                </div>
              )}
              <Button
                disabled={isVerifyingCode}
                type="submit"
                className="w-full bg-primaryColor hover:bg-primaryColor/90"
              >
                تایید
              </Button>
            </form>
          </Form>
        </>
      )}
      {step === LoginSteps.NAME && (
        <>
          <h1 className="text-xl font-bold">خوش آمدید</h1>
          <Form {...nameForm}>
            <form
              onSubmit={nameForm.handleSubmit(async (values) => {
                updateName(values)
              })}
              className="mt-6 space-y-6"
            >
              <FormField
                control={nameForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormDescription>
                      لطفا نام و نام خانوادگی خود را وارد کنید.
                    </FormDescription>
                    <FormControl>
                      <Input
                        autoComplete="false"
                        {...field}
                        className="h-[44px]"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                disabled={isUpdatingName}
                type="submit"
                className="w-full bg-primaryColor hover:bg-primaryColor/90"
              >
                ورود
              </Button>
            </form>
          </Form>
        </>
      )}
    </div>
  )
}

export default SignInForm
