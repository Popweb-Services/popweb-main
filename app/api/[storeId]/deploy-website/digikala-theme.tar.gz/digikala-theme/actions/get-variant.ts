import axios from "axios"

import { Variant } from "@/types/products"

export async function getVariantById(id: string): Promise<Variant> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/products/${id}`
  const { data } = await axios.get(url)
  return data as Variant
}
