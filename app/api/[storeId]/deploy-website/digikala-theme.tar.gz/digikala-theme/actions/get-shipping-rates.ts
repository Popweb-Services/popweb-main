import axios from "axios"

import { ShippingRate } from "@/types/shipping-rate"

export async function getShippingRates() {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/shipping-rates`
  const { data } = await axios.get(url)
  return data as ShippingRate[]
}
