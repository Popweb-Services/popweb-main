import axios from "axios"

import { ShippingRate } from "@/types/shipping-rate"

export async function getShippingRateById(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/shipping-rates/${id}`
  const { data } = await axios.get(url)
  return data as ShippingRate
}
