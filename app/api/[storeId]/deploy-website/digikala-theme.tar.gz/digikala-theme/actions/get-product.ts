import axios from "axios"

import { Product } from "@/types/products"

export async function getProductById(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/products/${id}`
  console.log(url)
  const { data } = await axios.get(url)
  console.log(data)
  return data as Product
}
