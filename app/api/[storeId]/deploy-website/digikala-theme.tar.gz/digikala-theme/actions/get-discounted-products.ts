import axios from "axios"

import { Product } from "@/types/products"

export default async function getDiscountedProducts(): Promise<Product[]> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/products/discounted`
  const { data } = await axios.get(url)
  return data as Product[]
}
