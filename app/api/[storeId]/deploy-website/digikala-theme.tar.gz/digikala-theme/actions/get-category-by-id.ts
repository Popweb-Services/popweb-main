import axios from "axios"

import { Category } from "@/types/products"

export async function getCategoryById(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/categories/${id}`
  const { data } = await axios.get(url)
  return data as Category
}
