import axios from "axios"

const url = `${process.env.NEXT_PUBLIC_API_URL}/logo`

export async function getLogo() {
  const { data } = await axios.get(url)
  return data
}
