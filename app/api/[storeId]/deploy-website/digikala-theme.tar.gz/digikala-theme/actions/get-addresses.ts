import axios from "axios"

import { Address } from "@/types/address"

export async function getAddresses(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/customers/addresses/${id}`
  const { data } = await axios.get(url)
  return data as Address[]
}
