import axios from "axios"

import { Store } from "@/types/store"

export async function getStore() {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/`
  const { data } = await axios.get(url)
  return data as Store
}
