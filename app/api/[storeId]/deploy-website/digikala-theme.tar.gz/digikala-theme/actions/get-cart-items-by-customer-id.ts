import axios from "axios"

import { CartItem } from "@/types/products"

export default async function getCartItemsByCustomerId(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/cart?customerId=${id}`
  const { data } = await axios.get(url)
  return data as CartItem[]
}
