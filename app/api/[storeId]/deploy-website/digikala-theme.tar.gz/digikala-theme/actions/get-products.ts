import axios from "axios"
import qs from "query-string"

import { Product } from "@/types/products"

interface Query {
  categoryId?: string
  isDiscounted?: boolean
  isFeatured?: boolean
}

export async function getProducts(query: Query): Promise<Product[]> {
  const url = qs.stringifyUrl({
    url: `${process.env.NEXT_PUBLIC_API_URL}/products`,
    query: {
      categoryId: query.categoryId,
      isDiscounted: query.isDiscounted,
      isFeatured: query.isFeatured,
    },
  })
  const { data } = await axios.get(url)

  return data
}
