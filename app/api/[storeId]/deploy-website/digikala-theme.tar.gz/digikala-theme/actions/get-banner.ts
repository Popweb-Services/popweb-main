import axios from "axios"

export async function getBanner(bannerId: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/banners/${bannerId}`
  const { data } = await axios.get(url)
  return data
}
