import axios from "axios"

import { Customer } from "@/types/customer"

export async function getCustomer(id: string) {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/customers/get/${id}`
  const { data } = await axios.get(url)
  return data as Customer
}
