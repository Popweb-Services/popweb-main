"use server"

import { cookies } from "next/headers"
import { v4 as uuid } from "uuid"

async function setDeviceIdCookie() {
  if (!cookies().has("device_id")) {
    cookies().set({
      name: "device_id",
      value: uuid(),
      httpOnly: true,
      path: "/",
    })
  }
}

export default setDeviceIdCookie
