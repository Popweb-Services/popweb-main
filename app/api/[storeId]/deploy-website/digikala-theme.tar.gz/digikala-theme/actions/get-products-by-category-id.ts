import axios from "axios"

import { Product } from "@/types/products"

export async function getProductsByCategoryId(id: string, queryString: string) {
  const PAGE_LIMIT = 1
  const url = `${process.env.NEXT_PUBLIC_API_URL}/products/categories/${id}?${queryString}`
  const { data } = await axios.get(url)
  return data as Product[]
}
