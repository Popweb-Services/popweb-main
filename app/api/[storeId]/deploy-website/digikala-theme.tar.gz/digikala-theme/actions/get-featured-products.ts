import axios from "axios"
import qs from "query-string"

import { Product } from "@/types/products"

export async function getFeaturedProducts(): Promise<Product[]> {
  const url = `${process.env.NEXT_PUBLIC_API_URL}/products/featured`
  const { data } = await axios.get(url)
  return data
}
