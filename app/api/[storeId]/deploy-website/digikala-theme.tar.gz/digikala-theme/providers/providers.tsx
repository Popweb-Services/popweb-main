"use client"

import { ReactNode, useEffect } from "react"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { Session } from "next-auth"
import { CookiesProvider, useCookies } from "react-cookie"
import { v4 as uuid } from "uuid"

import { Toaster } from "@/components/ui/toaster"

interface ProvidersProps {
  children: ReactNode
  session: Session | null
}

const Providers: React.FC<ProvidersProps> = ({ children, session }) => {
  const queryClient = new QueryClient()
  const [cookies, setCookie] = useCookies(["device_id"])
  useEffect(() => {
    if (!cookies.device_id && !session?.user) {
      setCookie("device_id", uuid())
    }
  }, [session])
  return (
    <>
      <CookiesProvider>
        <QueryClientProvider client={queryClient}>
          <Toaster />
          {children}
        </QueryClientProvider>
      </CookiesProvider>
    </>
  )
}

export default Providers
