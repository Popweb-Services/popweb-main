export type Store = {
  id: string
  name: string
  description: string
  bannerUrl?: string
  logoUrl?: string
}
