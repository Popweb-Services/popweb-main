export type ShippingRate = {
  id: string
  name: string
  description?: string
  price: number
  minPrice?: number
}
