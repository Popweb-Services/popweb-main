export type Product = {
  id: string
  name: string
  description?: any
  quantity: number
  price: number
  priceAfterDiscount?: number
  costAtPrice?: number
  unit?: string
  mainImageUrl: string
  images?: Image[]
  categoryId?: string
  category?: Category
  options?: Option[]
  variants: Variant[]
  features?: Feature[]
}

export type Category = {
  id: string
  name: string
  subcategories: Category[]
}

export type Option = {
  id: string
  name: string
  values: string[]
}

export type Image = {
  id: string
  imageUrl: string
}

export type Variant = {
  id: string
  options: string[]
  price: number
  priceAfterDiscount?: number
  quantity: number
}
export type Feature = {
  id: string
  name: string
  value: string
}

export type CartItem = {
  id: string
  product: Product
  variant?: Variant
  quantity: number
}
