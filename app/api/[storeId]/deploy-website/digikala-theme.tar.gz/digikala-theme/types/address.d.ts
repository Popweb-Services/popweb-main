export type Address = {
  id: string
  address: string
  postCode: string
  province: string
  city: string
  recieverName: string
  recieverPhoneNumber: string
}
